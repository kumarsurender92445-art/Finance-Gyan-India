import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight, BookOpen, Calculator, FileText } from 'lucide-react';
import { ARTICLES } from '../data/articles';
import { CALCULATORS } from '../data/calculators';
import { CATEGORIES } from '../data/categories';
import { Language } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  navigate: (path: string) => void;
  lang: Language;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  navigate,
  lang,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const normalized = query.trim().toLowerCase();

  const matchingArticles = normalized
    ? ARTICLES.filter(
        (a) =>
          a.title.toLowerCase().includes(normalized) ||
          a.titleHi.toLowerCase().includes(normalized) ||
          a.excerpt.toLowerCase().includes(normalized) ||
          a.excerptHi.toLowerCase().includes(normalized) ||
          a.tags.some((t) => t.toLowerCase().includes(normalized))
      )
    : [];

  const matchingCalculators = normalized
    ? CALCULATORS.filter(
        (c) =>
          c.name.toLowerCase().includes(normalized) ||
          c.nameHi.toLowerCase().includes(normalized) ||
          c.description.toLowerCase().includes(normalized) ||
          c.descriptionHi.toLowerCase().includes(normalized)
      )
    : [];

  const matchingCategories = normalized
    ? CATEGORIES.filter(
        (cat) =>
          cat.name.toLowerCase().includes(normalized) ||
          cat.nameHi.toLowerCase().includes(normalized) ||
          cat.description.toLowerCase().includes(normalized)
      )
    : [];

  const handleSelect = (path: string) => {
    onClose();
    navigate(path);
  };

  const handleViewAllResults = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      onClose();
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm p-4 sm:p-6 flex items-start justify-center pt-16 sm:pt-24 animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <form onSubmit={handleViewAllResults} className="flex items-center px-4 py-3.5 border-b border-slate-200 dark:border-slate-800">
          <Search className="w-5 h-5 text-slate-400 shrink-0 mr-3" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={
              lang === 'hi'
                ? 'SIP, लोन EMI, टैक्स स्लैब या लेख खोजें...'
                : 'Search SIP, EMI, Tax slabs, or articles...'
            }
            className="w-full bg-transparent text-sm sm:text-base text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 mr-2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="px-2 py-1 text-xs font-medium text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded"
          >
            Esc
          </button>
        </form>

        {/* Results Container */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-6">
          {!query && (
            <div className="text-center py-6">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                {lang === 'hi' ? 'लोकप्रिय खोजें' : 'Popular Searches'}
              </p>
              <div className="flex flex-wrap justify-center gap-2">
                {['SIP', 'Home Loan EMI', 'Old vs New Tax', 'Emergency Fund', '800 CIBIL', 'Sukanya Samriddhi'].map((keyword) => (
                  <button
                    key={keyword}
                    onClick={() => setQuery(keyword)}
                    className="px-3 py-1 text-xs rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-950 hover:text-teal-700 dark:hover:text-teal-300 transition-colors"
                  >
                    {keyword}
                  </button>
                ))}
              </div>
            </div>
          )}

          {query && matchingArticles.length === 0 && matchingCalculators.length === 0 && matchingCategories.length === 0 && (
            <div className="text-center py-10 text-sm text-slate-500 dark:text-slate-400">
              <p>{lang === 'hi' ? 'कोई परिणाम नहीं मिला।' : 'No results found.'}</p>
              <p className="text-xs text-slate-400 mt-1">
                {lang === 'hi' ? 'कृपया अन्य कीवर्ड या स्पेलिंग से खोजें।' : 'Try searching with different keywords.'}
              </p>
            </div>
          )}

          {/* Calculators match */}
          {matchingCalculators.length > 0 && (
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 flex items-center gap-1.5">
                <Calculator className="w-3.5 h-3.5 text-teal-600" />
                <span>{lang === 'hi' ? 'वित्तीय कैलकुलेटर' : 'Calculators'}</span>
              </div>
              <div className="space-y-1.5">
                {matchingCalculators.map((calc) => (
                  <button
                    key={calc.id}
                    onClick={() => handleSelect(`/calculator/${calc.slug}`)}
                    className="w-full text-left p-2.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/80 flex items-center justify-between group transition-colors"
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400">
                        {lang === 'hi' ? calc.nameHi : calc.name}
                      </div>
                      <div className="text-xs text-slate-500 line-clamp-1">
                        {lang === 'hi' ? calc.descriptionHi : calc.description}
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600 group-hover:translate-x-1 transition-all shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Articles match */}
          {matchingArticles.length > 0 && (
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-teal-600" />
                <span>{lang === 'hi' ? 'ब्लॉग आलेख' : 'Articles'}</span>
              </div>
              <div className="space-y-1.5">
                {matchingArticles.map((article) => (
                  <button
                    key={article.id}
                    onClick={() => handleSelect(`/article/${article.slug}`)}
                    className="w-full text-left p-2.5 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/80 flex items-center justify-between group transition-colors"
                  >
                    <div>
                      <div className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 line-clamp-1">
                        {lang === 'hi' ? article.titleHi : article.title}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                        {lang === 'hi' ? article.excerptHi : article.excerpt}
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600 group-hover:translate-x-1 transition-all shrink-0 ml-2" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Categories match */}
          {matchingCategories.length > 0 && (
            <div>
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-2 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5 text-teal-600" />
                <span>{lang === 'hi' ? 'श्रेणियां' : 'Categories'}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {matchingCategories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => handleSelect(`/category/${cat.slug}`)}
                    className="px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-teal-50 dark:hover:bg-teal-950 hover:text-teal-700 dark:hover:text-teal-300 transition-colors"
                  >
                    {lang === 'hi' ? cat.nameHi : cat.name} ({cat.articleCount})
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {query && (
          <div className="p-3 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 text-center">
            <button
              onClick={handleViewAllResults}
              className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline"
            >
              {lang === 'hi'
                ? `"${query}" के लिए सभी परिणाम सर्च पेज पर देखें →`
                : `View full results page for "${query}" →`}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
