import React, { useState } from 'react';
import { Search, Menu, X, Globe, Moon, Sun, Calculator } from 'lucide-react';
import { Language } from '../types';

interface HeaderProps {
  currentPath: string;
  navigate: (path: string) => void;
  lang: Language;
  toggleLang: () => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  openSearchModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPath,
  navigate,
  lang,
  toggleLang,
  darkMode,
  toggleDarkMode,
  openSearchModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: lang === 'hi' ? 'होम' : 'Home', path: '/' },
    { label: lang === 'hi' ? 'ब्लॉग' : 'Blog', path: '/blog' },
    { label: lang === 'hi' ? 'श्रेणियां' : 'Categories', path: '/categories' },
    { label: lang === 'hi' ? 'कैलकुलेटर' : 'Calculators', path: '/calculators' },
    { label: lang === 'hi' ? 'ट्रेंडिंग' : 'Trending', path: '/trending' },
  ];

  const handleNav = (path: string) => {
    setMobileMenuOpen(false);
    navigate(path);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text element Brand Wordmark */}
          <button
            onClick={() => handleNav('/')}
            className="flex items-center gap-2 text-left shrink-0 group focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 rounded"
          >
            <div className="w-8 h-8 rounded-lg bg-teal-700 flex items-center justify-center text-white font-bold text-lg shadow-sm">
              ₹
            </div>
            <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white whitespace-nowrap">
              Finance Gyan India
            </span>
          </button>

          {/* Zone 2: 4-5 Clean single-line text navigation links */}
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-300">
            {navLinks.map((link) => {
              const isActive = currentPath === link.path || (link.path !== '/' && currentPath.startsWith(link.path));
              return (
                <button
                  key={link.path}
                  onClick={() => handleNav(link.path)}
                  className={`whitespace-nowrap transition-colors py-1 ${
                    isActive
                      ? 'text-teal-700 dark:text-teal-400 font-semibold border-b-2 border-teal-700 dark:border-teal-400'
                      : 'hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions (Search, Language toggle, Calculator quick jump, mobile hamburger) */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Search trigger button */}
            <button
              onClick={openSearchModal}
              aria-label="खोजें / Search"
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Language Switcher */}
            <button
              onClick={toggleLang}
              aria-label="भाषा बदलें"
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-md hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors whitespace-nowrap"
            >
              <Globe className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
              <span>{lang === 'hi' ? 'EN' : 'हिंदी'}</span>
            </button>

            {/* Dark mode toggle */}
            <button
              onClick={toggleDarkMode}
              aria-label={darkMode ? 'लाइट मोड' : 'डार्क मोड'}
              className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Primary Action Button */}
            <button
              onClick={() => handleNav('/calculators')}
              className="hidden sm:flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-white bg-teal-700 dark:bg-teal-600 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap shadow-sm"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'वित्तीय टूल्स' : 'Calculators'}</span>
            </button>

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="मेनू खोलें"
              className="md:hidden p-2 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 pt-3 pb-6 shadow-xl animate-in fade-in duration-150">
          <nav className="flex flex-col space-y-2">
            {navLinks.map((link) => (
              <button
                key={link.path}
                onClick={() => handleNav(link.path)}
                className={`text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  currentPath === link.path
                    ? 'bg-teal-50 dark:bg-teal-950 text-teal-700 dark:text-teal-300 font-semibold'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {link.label}
              </button>
            ))}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-col gap-2">
              <button
                onClick={() => handleNav('/latest')}
                className="text-left px-3 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {lang === 'hi' ? 'नवीनतम लेख' : 'Latest Articles'}
              </button>
              <button
                onClick={() => handleNav('/authors')}
                className="text-left px-3 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {lang === 'hi' ? 'हमारे लेखक एवं विशेषज्ञ' : 'Editorial Team & Authors'}
              </button>
              <button
                onClick={() => handleNav('/about')}
                className="text-left px-3 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {lang === 'hi' ? 'हमारे बारे में' : 'About Us'}
              </button>
              <button
                onClick={() => handleNav('/contact')}
                className="text-left px-3 py-2 rounded-lg text-sm text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800"
              >
                {lang === 'hi' ? 'संपर्क करें' : 'Contact Us'}
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
