import React from 'react';
import { Clock, Calendar, ArrowRight } from 'lucide-react';
import { Article, Language } from '../types';
import { CATEGORIES } from '../data/categories';
import { AUTHORS } from '../data/authors';

interface ArticleCardProps {
  article: Article;
  navigate: (path: string) => void;
  lang: Language;
  layout?: 'standard' | 'compact' | 'featured';
}

export const ArticleCard: React.FC<ArticleCardProps> = ({
  article,
  navigate,
  lang,
  layout = 'standard',
}) => {
  const category = CATEGORIES.find((c) => c.slug === article.categorySlug);
  const author = AUTHORS.find((a) => a.id === article.authorId);

  const categoryName = category ? (lang === 'hi' ? category.nameHi : category.name) : '';
  const authorName = author ? (lang === 'hi' ? author.nameHi : author.name) : 'Finance Gyan Team';

  if (layout === 'compact') {
    return (
      <article
        onClick={() => navigate(`/article/${article.slug}`)}
        className="group cursor-pointer py-3 border-b border-slate-200 dark:border-slate-800 last:border-0"
      >
        <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
          <span className="font-medium text-teal-700 dark:text-teal-400">{categoryName}</span>
          <span aria-hidden="true">·</span>
          <span>{article.readTimeMinutes} min read</span>
        </div>
        <h4 className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors line-clamp-2 leading-snug">
          {lang === 'hi' ? article.titleHi : article.title}
        </h4>
      </article>
    );
  }

  if (layout === 'featured') {
    return (
      <article
        onClick={() => navigate(`/article/${article.slug}`)}
        className="group cursor-pointer bg-white dark:bg-slate-800/80 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col lg:flex-row"
      >
        <div className="lg:w-1/2 relative aspect-video lg:aspect-auto overflow-hidden bg-slate-100 dark:bg-slate-800">
          <img
            src={article.featuredImage}
            alt={article.featuredImageAlt}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
          />
        </div>
        <div className="lg:w-1/2 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            {/* Zero-Pill Unboxed Metadata with · separator */}
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-2">
              <span className="font-semibold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
                {categoryName}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {article.publishedDate}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {article.readTimeMinutes} min read
              </span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors tracking-tight leading-snug">
              {lang === 'hi' ? article.titleHi : article.title}
            </h2>

            <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 line-clamp-3 leading-relaxed">
              {lang === 'hi' ? article.excerptHi : article.excerpt}
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {lang === 'hi' ? 'लेखक' : 'By'}: <span className="font-medium text-slate-700 dark:text-slate-200">{authorName}</span>
            </span>
            <span className="text-xs font-semibold text-teal-700 dark:text-teal-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
              <span>{lang === 'hi' ? 'पूरा लेख पढ़ें' : 'Read Full Guide'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </article>
    );
  }

  // Standard card
  return (
    <article
      onClick={() => navigate(`/article/${article.slug}`)}
      className="group cursor-pointer bg-white dark:bg-slate-800/80 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 transition-all flex flex-col h-full"
    >
      <div className="relative aspect-video overflow-hidden bg-slate-100 dark:bg-slate-800">
        <img
          src={article.featuredImage}
          alt={article.featuredImageAlt}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
        />
      </div>

      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Zero-Pill Unboxed Metadata */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span className="font-semibold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
              {categoryName}
            </span>
            <span aria-hidden="true">·</span>
            <span className="flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" />
              {article.readTimeMinutes} min read
            </span>
          </div>

          <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors tracking-tight leading-snug line-clamp-2">
            {lang === 'hi' ? article.titleHi : article.title}
          </h3>

          <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed">
            {lang === 'hi' ? article.excerptHi : article.excerpt}
          </p>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span>{authorName}</span>
          <span className="flex items-center gap-1 font-medium text-teal-700 dark:text-teal-400 group-hover:translate-x-0.5 transition-transform">
            <span>{lang === 'hi' ? 'पढ़ें' : 'Read'}</span>
            <ArrowRight className="w-3 h-3" />
          </span>
        </div>
      </div>
    </article>
  );
};
