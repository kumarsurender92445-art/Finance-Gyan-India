import React, { useState } from 'react';
import { Mail, CheckCircle2, AlertCircle } from 'lucide-react';
import { CATEGORIES } from '../data/categories';
import { Language } from '../types';

interface FooterProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const Footer: React.FC<FooterProps> = ({ navigate, lang }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@') || !email.includes('.')) {
      setError(lang === 'hi' ? 'कृपया एक वैध ईमेल पता दर्ज करें।' : 'Please enter a valid email address.');
      return;
    }
    setError('');
    setSubscribed(true);
  };

  const legalLinks = [
    { label: lang === 'hi' ? 'गोपनीयता नीति' : 'Privacy Policy', path: '/privacy-policy' },
    { label: lang === 'hi' ? 'नियम और शर्तें' : 'Terms & Conditions', path: '/terms' },
    { label: lang === 'hi' ? 'अस्वीकरण' : 'Disclaimer', path: '/disclaimer' },
    { label: lang === 'hi' ? 'वित्तीय अस्वीकरण' : 'Financial Disclaimer', path: '/financial-disclaimer' },
    { label: lang === 'hi' ? 'एफिलिएट प्रकटीकरण' : 'Affiliate Disclosure', path: '/affiliate-disclosure' },
    { label: lang === 'hi' ? 'संपादकीय नीति' : 'Editorial Policy', path: '/editorial-policy' },
    { label: lang === 'hi' ? 'त्रुटि सुधार नीति' : 'Corrections Policy', path: '/corrections' },
    { label: lang === 'hi' ? 'कुकी नीति' : 'Cookie Policy', path: '/cookie-policy' },
    { label: lang === 'hi' ? 'साइटमैप' : 'HTML Sitemap', path: '/sitemap' },
  ];

  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 transition-colors">
      {/* Newsletter Section */}
      <div className="border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {lang === 'hi'
                ? 'स्मार्ट वित्तीय निर्णय लेने के लिए हर हफ्ते पाएं मुफ्त गाइड'
                : 'Get Weekly Financial Wisdom Directly in Your Inbox'}
            </h3>
            <p className="mt-2 text-sm text-slate-400">
              {lang === 'hi'
                ? 'बिना किसी स्पैम के, केवल बजट, निवेश, टैक्स सेविंग और नए सरकारी नियमों की प्रामाणिक जानकारी।'
                : 'Zero spam. Only authentic insights on budgeting, mutual funds, tax saving, and RBI updates.'}
            </p>

            <form onSubmit={handleSubscribe} className="mt-6 max-w-md mx-auto flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder={lang === 'hi' ? 'अपना ईमेल दर्ज करें' : 'Enter your email address'}
                  className="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-slate-700 text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
                />
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-teal-600 rounded-lg hover:bg-teal-500 transition-colors shrink-0"
              >
                {lang === 'hi' ? 'सब्सक्राइब करें' : 'Subscribe Free'}
              </button>
            </form>

            {error && (
              <p className="mt-2 text-xs text-rose-400 flex items-center justify-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>{error}</span>
              </p>
            )}

            {subscribed && (
              <p className="mt-2 text-xs text-emerald-400 flex items-center justify-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>
                  {lang === 'hi'
                    ? 'धन्यवाद! आप सफलतापूर्वक न्यूज़लेटर से जुड़ गए हैं।'
                    : 'Thank you! You have successfully subscribed.'}
                </span>
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Info */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center text-white font-bold text-lg">
                ₹
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                Finance Gyan India
              </span>
            </div>
            <p className="mt-3 text-sm text-slate-400 leading-relaxed max-w-sm">
              {lang === 'hi'
                ? 'भारतीय नागरिकों, वेतनभोगी कर्मचारियों, युवाओं और छोटे कारोबारियों को वित्तीय रूप से साक्षर और आत्मनिर्भर बनाने के उद्देश्य से समर्पित निष्पक्ष पोर्टल।'
                : 'Dedicated financial education portal helping Indian salaried individuals, students, and small business owners build long-term wealth.'}
            </p>
            <div className="mt-4 text-xs text-slate-400 space-y-1">
              <p>देश: भारत (India) · मुद्रा: भारतीय रुपया (₹)</p>
              <p>प्राथमिक भाषा: हिंदी (Hindi) एवं English</p>
            </div>
          </div>

          {/* Key Categories */}
          <div>
            <h4 className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-4">
              {lang === 'hi' ? 'प्रमुख श्रेणियां' : 'Top Categories'}
            </h4>
            <ul className="space-y-2 text-sm">
              {CATEGORIES.slice(0, 6).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => navigate(`/category/${cat.slug}`)}
                    className="hover:text-white transition-colors text-left"
                  >
                    {lang === 'hi' ? cat.nameHi : cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Financial Calculators */}
          <div>
            <h4 className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-4">
              {lang === 'hi' ? 'वित्तीय कैलकुलेटर' : 'Calculators'}
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => navigate('/calculator/sip-calculator')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'SIP कैलकुलेटर' : 'SIP Calculator'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/calculator/loan-emi-calculator')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'EMI कैलकुलेटर' : 'Loan EMI Calculator'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/calculator/home-loan-emi-calculator')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'होम लोन EMI' : 'Home Loan EMI'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/calculator/income-tax-estimator')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'इनकम टैक्स कैलकुलेटर' : 'Income Tax Estimator'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/calculator/monthly-budget-calculator')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'मासिक बजट (50/30/20)' : 'Monthly Budget'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/calculators')} className="text-teal-400 hover:text-teal-300 font-medium text-left">
                  {lang === 'hi' ? 'सभी 12+ कैलकुलेटर देखें →' : 'View all 12+ tools →'}
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Links & Trust */}
          <div>
            <h4 className="text-xs uppercase tracking-wider text-slate-400 font-semibold mb-4">
              {lang === 'hi' ? 'कंपनी एवं नीतियां' : 'Trust & Policies'}
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => navigate('/about')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'हमारे बारे में' : 'About Us'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/authors')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'विशेषज्ञ लेखक टीम' : 'Editorial Authors'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/contact')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'संपर्क करें' : 'Contact Us'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/editorial-policy')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'संपादकीय दिशा-निर्देश' : 'Editorial Guidelines'}
                </button>
              </li>
              <li>
                <button onClick={() => navigate('/financial-disclaimer')} className="hover:text-white transition-colors text-left">
                  {lang === 'hi' ? 'वित्तीय जोखिम सूचना' : 'Risk Disclaimer'}
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Legal Links Bar */}
        <div className="mt-10 pt-6 border-t border-slate-800 flex flex-wrap gap-x-6 gap-y-2 text-xs text-slate-400">
          {legalLinks.map((link) => (
            <button
              key={link.path}
              onClick={() => navigate(link.path)}
              className="hover:text-white transition-colors"
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Mandatory Regulatory / Financial Safety Disclaimer */}
        <div className="mt-8 p-4 rounded-lg bg-slate-800/70 border border-slate-800 text-xs text-slate-400 leading-relaxed">
          <p className="font-semibold text-slate-300 mb-1">
            {lang === 'hi' ? 'महत्वपूर्ण वित्तीय एवं विनियामक अस्वीकरण (Disclaimer):' : 'Important Regulatory & Financial Disclaimer:'}
          </p>
          <p>
            {lang === 'hi'
              ? 'Finance Gyan India (फाइनेंस ज्ञान इंडिया) एक वित्तीय शिक्षा और सूचनात्मक ब्लॉग पोर्टल है। यह SEBI (भारतीय प्रतिभूति और विनिमय बोर्ड) या RBI के तहत पंजीकृत निवेश सलाहकार या ब्रोकर नहीं है। इस वेबसाइट पर प्रकाशित सभी आलेख, गणनाएं और मार्गदर्शिकाएं केवल सामान्य जानकारी व वित्तीय साक्षरता के उद्देश्य से हैं। हम किसी भी शेयर, म्यूचुअल फंड, पॉलिसी या वित्तीय उत्पाद में निवेश करने की व्यक्तिगत सलाह नहीं देते। म्यूचुअल फंड एवं इक्विटी निवेश बाजार जोखिमों के अधीन हैं। कोई भी वित्तीय फैसला लेने से पहले अपने SEBI-पंजीकृत वित्तीय सलाहकार (RIA/CFP) या चार्टर्ड अकाउंटेंट से परामर्श अवश्य लें।'
              : 'Finance Gyan India is an educational and informational portal. It does not provide personalized investment advice or act as a registered broker under SEBI or RBI. All materials and calculator estimates are for illustrative and educational purposes only. Mutual fund investments are subject to market risks. Please consult a SEBI-registered financial advisor before investing.'}
          </p>
        </div>

        {/* Bottom copyright */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} Finance Gyan India. All rights reserved.</p>
          <p className="text-slate-500">
            {lang === 'hi' ? 'भारतीय पाठकों के लिए निष्पक्ष एवं पारदर्शी वित्तीय ज्ञान' : 'Unbiased Financial Knowledge for Indian Citizens'}
          </p>
        </div>
      </div>
    </footer>
  );
};
