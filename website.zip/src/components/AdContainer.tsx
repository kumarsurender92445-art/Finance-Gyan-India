import React from 'react';

interface AdContainerProps {
  slotId?: string;
  format?: 'horizontal' | 'rectangle' | 'in-article';
  className?: string;
}

export const AdContainer: React.FC<AdContainerProps> = ({
  slotId = 'ca-pub-finance-gyan-placeholder',
  format = 'horizontal',
  className = '',
}) => {
  return (
    <div
      className={`my-6 mx-auto w-full max-w-4xl p-3 bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-300 dark:border-slate-700 rounded-lg text-center ${className}`}
      aria-label="विज्ञापन / Advertisement container"
    >
      <div className="flex items-center justify-between text-[11px] text-slate-400 dark:text-slate-500 mb-2 px-1">
        <span className="uppercase tracking-widest font-mono">विज्ञापन / ADVERTISEMENT</span>
        <span className="text-[10px] font-mono">Ad Slot: {slotId}</span>
      </div>

      <div
        className={`flex flex-col items-center justify-center rounded bg-slate-100 dark:bg-slate-800/80 text-slate-400 dark:text-slate-500 text-xs ${
          format === 'horizontal'
            ? 'h-24 sm:h-28 w-full'
            : format === 'rectangle'
            ? 'h-64 w-full max-w-sm mx-auto'
            : 'h-32 w-full'
        }`}
      >
        <span className="font-medium text-slate-600 dark:text-slate-300">
          Google AdSense Responsive Unit
        </span>
        <span className="text-[11px] text-slate-400 mt-1">
          (वास्तविक AdSense प्रकाशक आईडी व विज्ञापन कोड से ऑटो-रिप्लेस होगा)
        </span>
      </div>
    </div>
  );
};
