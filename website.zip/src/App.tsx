import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SearchModal } from './components/SearchModal';
import { HomePage } from './pages/HomePage';
import { BlogPage } from './pages/BlogPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { CategoryDetailPage } from './pages/CategoryDetailPage';
import { ArticleDetailPage } from './pages/ArticleDetailPage';
import { CalculatorsPage } from './pages/CalculatorsPage';
import { CalculatorDetailPage } from './pages/CalculatorDetailPage';
import { SearchPage } from './pages/SearchPage';
import { AuthorsPage } from './pages/AuthorsPage';
import { AuthorDetailPage } from './pages/AuthorDetailPage';
import { TrendingPage } from './pages/TrendingPage';
import { LatestPage } from './pages/LatestPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { LegalPage, LegalDocType } from './pages/LegalPage';
import { SitemapPage } from './pages/SitemapPage';
import { NotFoundPage } from './pages/NotFoundPage';

import { ARTICLES } from './data/articles';
import { CATEGORIES } from './data/categories';
import { CALCULATORS } from './data/calculators';
import { AUTHORS } from './data/authors';
import { Language } from './types';

export default function App() {
  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  const [lang, setLang] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('fg_lang');
      if (saved === 'hi' || saved === 'en') return saved;
    }
    return 'hi'; // Hindi primary default
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('fg_dark') === 'true';
    }
    return false;
  });

  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);

  // Sync dark mode class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('fg_dark', 'true');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('fg_dark', 'false');
    }
  }, [darkMode]);

  // Sync language
  const toggleLang = () => {
    const nextLang = lang === 'hi' ? 'en' : 'hi';
    setLang(nextLang);
    localStorage.setItem('fg_lang', nextLang);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Back to top scroll listener
  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Browser navigation history support
  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    if (path !== currentPath) {
      window.history.pushState({}, '', path);
      setCurrentPath(path.split('?')[0]);
      window.scrollTo({ top: 0, behavior: 'instant' });
    }
  };

  // Route Dispatcher
  const renderCurrentPage = () => {
    const path = currentPath;

    // Homepage
    if (path === '/' || path === '/index.html' || path === '') {
      return <HomePage navigate={navigate} lang={lang} />;
    }

    // Blog Archive
    if (path === '/blog' || path === '/blog.html') {
      return <BlogPage navigate={navigate} lang={lang} />;
    }

    // All Categories
    if (path === '/categories' || path === '/categories.html') {
      return <CategoriesPage navigate={navigate} lang={lang} />;
    }

    // Specific Category: /category/:slug
    if (path.startsWith('/category/')) {
      const slug = path.replace('/category/', '').replace('.html', '');
      const category = CATEGORIES.find((c) => c.slug === slug);
      if (category) {
        return <CategoryDetailPage category={category} navigate={navigate} lang={lang} />;
      }
    }

    // Individual Blog Article: /article/:slug
    if (path.startsWith('/article/')) {
      const slug = path.replace('/article/', '').replace('.html', '');
      const article = ARTICLES.find((a) => a.slug === slug);
      if (article) {
        return <ArticleDetailPage article={article} navigate={navigate} lang={lang} />;
      }
    }

    // Calculators Hub
    if (path === '/calculators' || path === '/calculators.html') {
      return <CalculatorsPage navigate={navigate} lang={lang} />;
    }

    // Specific Calculator: /calculator/:slug
    if (path.startsWith('/calculator/')) {
      const slug = path.replace('/calculator/', '').replace('.html', '');
      const calculator = CALCULATORS.find((c) => c.slug === slug || c.id === slug);
      if (calculator) {
        return <CalculatorDetailPage calculator={calculator} navigate={navigate} lang={lang} />;
      }
    }

    // Search Page
    if (path === '/search' || path === '/search.html') {
      return <SearchPage navigate={navigate} lang={lang} />;
    }

    // Trending & Latest
    if (path === '/trending' || path === '/trending.html') {
      return <TrendingPage navigate={navigate} lang={lang} />;
    }
    if (path === '/latest' || path === '/latest.html') {
      return <LatestPage navigate={navigate} lang={lang} />;
    }

    // Authors & Author Profile
    if (path === '/authors' || path === '/authors.html') {
      return <AuthorsPage navigate={navigate} lang={lang} />;
    }
    if (path.startsWith('/author/')) {
      const id = path.replace('/author/', '').replace('.html', '');
      const author = AUTHORS.find((a) => a.id === id);
      if (author) {
        return <AuthorDetailPage author={author} navigate={navigate} lang={lang} />;
      }
    }

    // About & Contact
    if (path === '/about' || path === '/about.html') {
      return <AboutPage navigate={navigate} lang={lang} />;
    }
    if (path === '/contact' || path === '/contact.html') {
      return <ContactPage navigate={navigate} lang={lang} />;
    }

    // Legal Pages
    const legalRoutes: Record<string, LegalDocType> = {
      '/privacy-policy': 'privacy-policy',
      '/privacy-policy.html': 'privacy-policy',
      '/terms': 'terms',
      '/terms.html': 'terms',
      '/disclaimer': 'disclaimer',
      '/disclaimer.html': 'disclaimer',
      '/financial-disclaimer': 'financial-disclaimer',
      '/financial-disclaimer.html': 'financial-disclaimer',
      '/affiliate-disclosure': 'affiliate-disclosure',
      '/affiliate-disclosure.html': 'affiliate-disclosure',
      '/editorial-policy': 'editorial-policy',
      '/editorial-policy.html': 'editorial-policy',
      '/corrections': 'corrections',
      '/corrections.html': 'corrections',
      '/cookie-policy': 'cookie-policy',
      '/cookie-policy.html': 'cookie-policy',
    };

    if (legalRoutes[path]) {
      return <LegalPage type={legalRoutes[path]} navigate={navigate} lang={lang} />;
    }

    // Sitemap
    if (path === '/sitemap' || path === '/sitemap.html') {
      return <SitemapPage navigate={navigate} lang={lang} />;
    }

    // 404 Fallback
    return <NotFoundPage navigate={navigate} lang={lang} />;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans selection:bg-teal-700 selection:text-white transition-colors duration-150">
      {/* Top Header */}
      <Header
        currentPath={currentPath}
        navigate={navigate}
        lang={lang}
        toggleLang={toggleLang}
        darkMode={darkMode}
        toggleDarkMode={toggleDarkMode}
        openSearchModal={() => setSearchModalOpen(true)}
      />

      {/* Main Page Area */}
      <main className="flex-1">
        {renderCurrentPage()}
      </main>

      {/* Footer */}
      <Footer navigate={navigate} lang={lang} />

      {/* Search Modal */}
      <SearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        navigate={navigate}
        lang={lang}
      />

      {/* Back to Top Floating Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          aria-label="वापस ऊपर जाएं"
          className="fixed bottom-6 right-6 z-40 p-3 bg-teal-700 hover:bg-teal-800 text-white rounded-full shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 animate-in fade-in"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}
    </div>
  );
}
