import { CalculatorConfig } from '../types';

export const CALCULATORS: CalculatorConfig[] = [
  {
    id: 'sip-calculator',
    slug: 'sip-calculator',
    name: 'SIP Return Estimator',
    nameHi: 'एसआईपी (SIP) रिटर्न कैलकुलेटर',
    description: 'Calculate wealth growth and expected returns on your monthly mutual fund SIP.',
    descriptionHi: 'म्यूचुअल फंड में अपनी मासिक SIP पर मिलने वाले संभावित रिटर्न और वेल्थ क्रिएशन का हिसाब लगाएं।',
    category: 'investment',
    iconName: 'Coins',
    fields: [
      { id: 'monthlyInvestment', label: 'Monthly Investment', labelHi: 'मासिक निवेश (₹)', defaultValue: 5000, min: 500, max: 200000, step: 500, unit: '₹' },
      { id: 'expectedRate', label: 'Expected Return Rate (p.a)', labelHi: 'अनुमानित रिटर्न दर (% p.a)', defaultValue: 12, min: 1, max: 30, step: 0.5, unit: '%' },
      { id: 'timePeriod', label: 'Time Period', labelHi: 'समय अवधि (वर्ष)', defaultValue: 10, min: 1, max: 40, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'M = P × ({[1 + i]^n – 1} / i) × (1 + i)',
      explanationHi: 'जहाँ P = मासिक निवेश, i = मासिक ब्याज दर (r / 12 / 100), n = कुल महीनों की संख्या (वर्ष × 12)।',
      variables: [
        { symbol: 'M', nameHi: 'मैच्योरिटी राशि', desc: 'अवधि पूरी होने पर प्राप्त कुल अनुमानित राशि' },
        { symbol: 'P', nameHi: 'मासिक SIP', desc: 'हर महीने बैंक से कटने वाली तय रकम' },
        { symbol: 'i', nameHi: 'मासिक ब्याज दर', desc: 'वार्षिक रिटर्न दर को 12 से विभाजित करके' },
        { symbol: 'n', nameHi: 'कुल महीने', desc: 'वर्षों की संख्या को 12 से गुणा करके' }
      ]
    },
    assumptions: [
      'रिटर्न की गणना वार्षिक चक्रवृद्धि (Annualized Compound Rate) के आधार पर की गई है।',
      'म्यूचुअल फंड रिटर्न बाजार के उतार-चढ़ाव पर निर्भर करते हैं, यह एक सांकेतिक अनुमान है, कोई गारंटी नहीं।'
    ]
  },
  {
    id: 'loan-emi-calculator',
    slug: 'loan-emi-calculator',
    name: 'Loan EMI Calculator',
    nameHi: 'लोन ईएमआई (EMI) कैलकुलेटर',
    description: 'Calculate monthly EMI, total interest, and total payment for any bank loan.',
    descriptionHi: 'किसी भी बैंक लोन के लिए मासिक ईएमआई, कुल देय ब्याज और कुल पुनर्भुगतान की सटीक गणना करें।',
    category: 'loans',
    iconName: 'Landmark',
    fields: [
      { id: 'loanAmount', label: 'Loan Amount', labelHi: 'लोन राशि (₹)', defaultValue: 1000000, min: 10000, max: 10000000, step: 10000, unit: '₹' },
      { id: 'interestRate', label: 'Interest Rate (p.a)', labelHi: 'ब्याज दर (% p.a)', defaultValue: 9.5, min: 5, max: 25, step: 0.1, unit: '%' },
      { id: 'loanTenure', label: 'Tenure (Years)', labelHi: 'लोन अवधि (वर्ष)', defaultValue: 5, min: 1, max: 30, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'EMI = [P × R × (1+R)^N] / [(1+R)^N - 1]',
      explanationHi: 'जहाँ P = मूलधन (Principal), R = मासिक ब्याज दर, N = कुल महीनों की संख्या।',
      variables: [
        { symbol: 'P', nameHi: 'लोन मूलधन', desc: 'बैंक द्वारा स्वीकृत कुल कर्ज राशि' },
        { symbol: 'R', nameHi: 'मासिक दर', desc: 'वार्षिक ब्याज दर / 12 / 100' },
        { symbol: 'N', nameHi: 'कुल किस्तें', desc: 'लोन अवधि × 12 महीने' }
      ]
    },
    assumptions: [
      'गणना समान मासिक किस्त (Equated Monthly Installment) फॉर्मूले पर आधारित है।',
      'प्रोसेसिंग फीस, GST और प्रीपेमेंट चार्ज इसमें शामिल नहीं हैं।'
    ]
  },
  {
    id: 'home-loan-emi-calculator',
    slug: 'home-loan-emi-calculator',
    name: 'Home Loan EMI Calculator',
    nameHi: 'होम लोन ईएमआई कैलकुलेटर',
    description: 'Tailored for long-term housing loans with amortization schedules.',
    descriptionHi: 'दीर्घकालिक आवास ऋण, मूलधन-ब्याज अनुपात और लंबी अवधि की आसान योजना।',
    category: 'loans',
    iconName: 'Home',
    fields: [
      { id: 'loanAmount', label: 'Home Loan Amount', labelHi: 'होम लोन राशि (₹)', defaultValue: 4000000, min: 500000, max: 50000000, step: 100000, unit: '₹' },
      { id: 'interestRate', label: 'Home Loan Interest Rate', labelHi: 'होम लोन ब्याज दर (% p.a)', defaultValue: 8.5, min: 7.0, max: 14, step: 0.1, unit: '%' },
      { id: 'loanTenure', label: 'Tenure (Years)', labelHi: 'अवधि (वर्ष)', defaultValue: 20, min: 5, max: 30, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'EMI = [P × R × (1+R)^N] / [(1+R)^N - 1]',
      explanationHi: 'हाउसिंग लोन की ईएमआई गणना के लिए मानक रिड्यूसिंग बैलेंस विधि का उपयोग किया जाता है।',
      variables: [
        { symbol: 'P', nameHi: 'लोन राशि', desc: 'फ्लैट या मकान के लिए लिया गया ऋण' },
        { symbol: 'R', nameHi: 'मासिक ब्याज दर', desc: 'फ्लोटिंग या फिक्स्ड ब्याज दर का मासिक अंश' },
        { symbol: 'N', nameHi: 'अवधि', desc: 'महीनों की संख्या (12 से 360 महीने)' }
      ]
    },
    assumptions: [
      'फ्लोटिंग ब्याज दर समय के साथ RBI के रेपो रेट के अनुसार बदल सकती है।'
    ]
  },
  {
    id: 'personal-loan-calculator',
    slug: 'personal-loan-calculator',
    name: 'Personal Loan EMI Calculator',
    nameHi: 'पर्सनल लोन ईएमआई कैलकुलेटर',
    description: 'Quick estimation for short-to-medium unsecured personal borrowings.',
    descriptionHi: 'कम अवधि के अनसिक्योर्ड पर्सनल लोन की मासिक किस्त व ब्याज का तेज विश्लेषण।',
    category: 'loans',
    iconName: 'CreditCard',
    fields: [
      { id: 'loanAmount', label: 'Personal Loan Amount', labelHi: 'पर्सनल लोन राशि (₹)', defaultValue: 300000, min: 25000, max: 2500000, step: 10000, unit: '₹' },
      { id: 'interestRate', label: 'Interest Rate', labelHi: 'ब्याज दर (% p.a)', defaultValue: 12.5, min: 10.5, max: 24, step: 0.25, unit: '%' },
      { id: 'loanTenure', label: 'Tenure (Years)', labelHi: 'अवधि (वर्ष)', defaultValue: 3, min: 1, max: 7, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'EMI = [P × R × (1+R)^N] / [(1+R)^N - 1]',
      explanationHi: 'पर्सनल लोन में ब्याज दरें क्रेडिट स्कोर के आधार पर 10.5% से 22% तक हो सकती हैं।',
      variables: [
        { symbol: 'P', nameHi: 'ऋण राशि', desc: 'कुल पर्सनल लोन राशि' }
      ]
    },
    assumptions: [
      'अधिकांश बैंकों द्वारा 1% से 2.5% + GST प्रोसेसिंग फीस ली जाती है।'
    ]
  },
  {
    id: 'monthly-budget-calculator',
    slug: 'monthly-budget-calculator',
    name: 'Monthly Budget Calculator (50/30/20)',
    nameHi: 'मासिक बजट कैलकुलेटर (50/30/20 नियम)',
    description: 'Split your monthly take-home salary into Needs, Wants, and Savings.',
    descriptionHi: 'अपनी इन-हैंड सैलरी को 50% जरूरतें, 30% शौक और 20% अनिवार्य बचत में विभाजित करें।',
    category: 'planning',
    iconName: 'PieChart',
    fields: [
      { id: 'monthlyIncome', label: 'Monthly In-Hand Salary', labelHi: 'मासिक इन-हैंड सैलरी (₹)', defaultValue: 60000, min: 10000, max: 1000000, step: 1000, unit: '₹' },
      { id: 'needsRatio', label: 'Needs % (Home, Groceries, Bills)', labelHi: 'जरूरतें % (राशन, किराया, ईएमआई)', defaultValue: 50, min: 30, max: 70, step: 5, unit: '%' },
      { id: 'wantsRatio', label: 'Wants % (Dining, Shopping, Movies)', labelHi: 'इच्छाएं % (शॉपिंग, घूमना, मनोरंजन)', defaultValue: 30, min: 10, max: 50, step: 5, unit: '%' }
    ],
    formulaExplanation: {
      formula: 'बचत राशि = कुल आय - (जरूरतें + इच्छाएं)',
      explanationHi: 'अमेरिकी अर्थशास्त्री एलिजाबेथ वॉरेन द्वारा प्रतिपादित 50/30/20 नियम आम भारतीय वेतनभोगियों के लिए वित्तीय संतुलन का सर्वश्रेष्ठ साधन है।',
      variables: [
        { symbol: 'Needs', nameHi: 'अनिवार्य खर्च (50%)', desc: 'रोटी, कपड़ा, मकान, बिजली, स्कूल फीस' },
        { symbol: 'Wants', nameHi: 'जीवनशैली (30%)', desc: 'डाइनिंग आउट, वेकेशन, गैजेट्स' },
        { symbol: 'Savings', nameHi: 'भविष्य की बचत (20%)', desc: 'SIP, इमरजेंसी फंड, पीपीएफ' }
      ]
    },
    assumptions: [
      'यह गणना टैक्स कटने के बाद मिलने वाली नेट इन-हैंड सैलरी पर लागू होती है।'
    ]
  },
  {
    id: 'savings-goal-calculator',
    slug: 'savings-goal-calculator',
    name: 'Savings Goal Calculator',
    nameHi: 'बचत लक्ष्य (Savings Goal) कैलकुलेटर',
    description: 'Find out how much you need to save every month to buy a car, house downpayment, or wedding.',
    descriptionHi: 'गाड़ी, घर का डाउनपेमेंट या शादी के लिए तय समय में जरूरी रकम जुटाने हेतु मासिक बचत जानें।',
    category: 'planning',
    iconName: 'PiggyBank',
    fields: [
      { id: 'targetAmount', label: 'Target Goal Amount', labelHi: 'लक्ष्य राशि (₹)', defaultValue: 1000000, min: 50000, max: 20000000, step: 50000, unit: '₹' },
      { id: 'currentSavings', label: 'Already Saved Amount', labelHi: 'मौजूदा बचत (₹)', defaultValue: 100000, min: 0, max: 10000000, step: 10000, unit: '₹' },
      { id: 'yearsToGoal', label: 'Years to Goal', labelHi: 'लक्ष्य तक का समय (वर्ष)', defaultValue: 5, min: 1, max: 25, step: 1, unit: 'Years' },
      { id: 'expectedReturn', label: 'Expected Return (% p.a)', labelHi: 'अनुमानित रिटर्न (% p.a)', defaultValue: 10, min: 4, max: 18, step: 0.5, unit: '%' }
    ],
    formulaExplanation: {
      formula: 'मासिक बचत = (लक्ष्य राशि - मौजूदा बचत की फ्यूचर वैल्यू) / SIP फ्यूचर वैल्यू फैक्टर',
      explanationHi: 'यह कैलकुलेटर मौजूदा बचत के कंपाउंडिंग ग्रोथ को घटाकर शुद्ध आवश्यक मासिक निवेश बताता है।',
      variables: [
        { symbol: 'Goal', nameHi: 'लक्ष्य राशि', desc: 'आवश्यक कुल कोष' }
      ]
    },
    assumptions: [
      'समय अवधि के दौरान मुद्रास्फीति (महंगाई) को ध्यान में रखकर लक्ष्य राशि तय करें।'
    ]
  },
  {
    id: 'fd-calculator',
    slug: 'fd-calculator',
    name: 'Fixed Deposit (FD) Calculator',
    nameHi: 'फिक्स्ड डिपॉजिट (FD) कैलकुलेटर',
    description: 'Calculate interest earned and maturity payout on bank fixed deposits.',
    descriptionHi: 'बैंक एफडी पर मिलने वाले तिमाही चक्रवृद्धि ब्याज और मैच्योरिटी राशि की गणना करें।',
    category: 'banking',
    iconName: 'Building2',
    fields: [
      { id: 'depositAmount', label: 'Total Deposit Amount', labelHi: 'कुल जमा राशि (₹)', defaultValue: 100000, min: 5000, max: 5000000, step: 5000, unit: '₹' },
      { id: 'interestRate', label: 'FD Interest Rate (% p.a)', labelHi: 'ब्याज दर (% p.a)', defaultValue: 7.1, min: 3, max: 12, step: 0.1, unit: '%' },
      { id: 'tenureYears', label: 'Tenure (Years)', labelHi: 'अवधि (वर्ष)', defaultValue: 3, min: 1, max: 10, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'A = P × (1 + r/4)^(4 × t)',
      explanationHi: 'भारतीय बैंक सामान्यतः फिक्स्ड डिपॉजिट पर त्रैमासिक (Quarterly) कंपाउंडिंग ब्याज देते हैं।',
      variables: [
        { symbol: 'A', nameHi: 'मैच्योरिटी राशि', desc: 'कुल मिलने वाली रकम' },
        { symbol: 'P', nameHi: 'मूलधन', desc: 'जमा की गई राशि' },
        { symbol: 'r', nameHi: 'वार्षिक ब्याज दर', desc: 'बैंक द्वारा तय दर' },
        { symbol: 't', nameHi: 'समय अवधि', desc: 'वर्षों में' }
      ]
    },
    assumptions: [
      'गणना भारतीय बैंकों के मानक त्रैमासिक चक्रवृद्धि चक्र पर आधारित है।',
      'टीडीएस (TDS) कटौती करदाता के टैक्स स्लैब के अनुसार अलग हो सकती है।'
    ]
  },
  {
    id: 'rd-calculator',
    slug: 'rd-calculator',
    name: 'Recurring Deposit (RD) Calculator',
    nameHi: 'आरडी (Recurring Deposit) कैलकुलेटर',
    description: 'Calculate maturity value for monthly recurring deposits in banks and post offices.',
    descriptionHi: 'बैंक व डाकघर में हर महीने जमा होने वाली आरडी के मैच्योरिटी मूल्य की गणना।',
    category: 'banking',
    iconName: 'CalendarClock',
    fields: [
      { id: 'monthlyDeposit', label: 'Monthly Deposit Amount', labelHi: 'मासिक जमा (₹)', defaultValue: 3000, min: 500, max: 100000, step: 500, unit: '₹' },
      { id: 'interestRate', label: 'RD Interest Rate (% p.a)', labelHi: 'ब्याज दर (% p.a)', defaultValue: 6.8, min: 3, max: 10, step: 0.1, unit: '%' },
      { id: 'tenureYears', label: 'Tenure (Years)', labelHi: 'अवधि (वर्ष)', defaultValue: 3, min: 1, max: 10, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'M = P × [(1 + r)^n - 1] / [1 - (1 + r)^(-1/3)]',
      explanationHi: 'आरडी में हर महीने जमा होने वाली किस्त पर तिमाही चक्रवृद्धि ब्याज के नियम लागू होते हैं।',
      variables: [
        { symbol: 'P', nameHi: 'मासिक किस्त', desc: 'प्रति माह जमा राशि' }
      ]
    },
    assumptions: [
      'ब्याज त्रैमासिक रूप से संयोजित (Quarterly Compounded) होता है।'
    ]
  },
  {
    id: 'compound-interest-calculator',
    slug: 'compound-interest-calculator',
    name: 'Compound Interest Calculator',
    nameHi: 'चक्रवृद्धि ब्याज कैलकुलेटर',
    description: 'See how frequent compounding turns small sums into massive wealth.',
    descriptionHi: 'देखें कैसे वार्षिक, छमाही या मासिक कंपाउंडिंग से आपका पैसा तेजी से बढ़ता है।',
    category: 'investment',
    iconName: 'TrendingUp',
    fields: [
      { id: 'principal', label: 'Initial Principal Amount', labelHi: 'प्रारंभिक मूलधन (₹)', defaultValue: 200000, min: 1000, max: 10000000, step: 10000, unit: '₹' },
      { id: 'rate', label: 'Annual Interest Rate (%)', labelHi: 'वार्षिक ब्याज दर (%)', defaultValue: 11, min: 1, max: 30, step: 0.5, unit: '%' },
      { id: 'years', label: 'Time Horizon (Years)', labelHi: 'समय अवधि (वर्ष)', defaultValue: 10, min: 1, max: 40, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'A = P × (1 + r/n)^(n × t)',
      explanationHi: 'चक्रवृद्धि ब्याज में आपको ब्याज के ऊपर भी ब्याज मिलता है, जिससे घातीय वृद्धि (Exponential Growth) होती है।',
      variables: [
        { symbol: 'A', nameHi: 'कुल राशि', desc: 'मूलधन + कुल संचित ब्याज' }
      ]
    },
    assumptions: [
      'वार्षिक चक्रवृद्धि आधार मानकर गणना की गई है।'
    ]
  },
  {
    id: 'inflation-calculator',
    slug: 'inflation-calculator',
    name: 'Inflation Calculator',
    nameHi: 'मुद्रास्फीति (Inflation) कैलकुलेटर',
    description: 'Calculate the future purchasing power of your rupee and cost of living.',
    descriptionHi: 'जानें आज के ₹1 लाख की 10, 20 या 30 साल बाद क्या वैल्यू रह जाएगी और खर्च कितना बढ़ जाएगा।',
    category: 'planning',
    iconName: 'TrendingDown',
    fields: [
      { id: 'currentExpenses', label: 'Current Cost / Expense', labelHi: 'आज का खर्च या राशि (₹)', defaultValue: 50000, min: 5000, max: 1000000, step: 5000, unit: '₹' },
      { id: 'inflationRate', label: 'Expected Inflation (% p.a)', labelHi: 'अनुमानित महंगाई दर (% p.a)', defaultValue: 6.0, min: 2, max: 12, step: 0.25, unit: '%' },
      { id: 'yearsAhead', label: 'Years Ahead', labelHi: 'भविष्य के वर्ष', defaultValue: 15, min: 1, max: 40, step: 1, unit: 'Years' }
    ],
    formulaExplanation: {
      formula: 'Future Cost = Present Cost × (1 + i)^t',
      explanationHi: 'मुद्रास्फीति आपके पैसे की क्रय शक्ति (Purchasing Power) को लगातार कम करती है।',
      variables: [
        { symbol: 'i', nameHi: 'महंगाई दर', desc: 'वार्षिक औसत CPI मुद्रास्फीति' },
        { symbol: 't', nameHi: 'वर्ष', desc: 'कितने साल बाद' }
      ]
    },
    assumptions: [
      'भारत में ऐतिहासिक खुदरा महंगाई दर (CPI) औसतन 5.5% से 6.5% के बीच रही है।'
    ]
  },
  {
    id: 'retirement-corpus-calculator',
    slug: 'retirement-corpus-calculator',
    name: 'Retirement Corpus Estimator',
    nameHi: 'रिटायरमेंट फंड (Corpus) कैलकुलेटर',
    description: 'Calculate the total corpus required for a worry-free financial retirement.',
    descriptionHi: 'महंगाई और जीवन प्रत्याशा को जोड़कर रिटायरमेंट के लिए जरूरी कुल फंड और मासिक बचत जानें।',
    category: 'planning',
    iconName: 'Clock',
    fields: [
      { id: 'currentAge', label: 'Current Age', labelHi: 'आपकी वर्तमान आयु', defaultValue: 30, min: 20, max: 55, step: 1, unit: 'Years' },
      { id: 'retirementAge', label: 'Planned Retirement Age', labelHi: 'रिटायरमेंट की आयु', defaultValue: 60, min: 45, max: 70, step: 1, unit: 'Years' },
      { id: 'monthlyExpenseNow', label: 'Monthly Expenses Today (₹)', labelHi: 'आज का मासिक खर्च (₹)', defaultValue: 40000, min: 10000, max: 300000, step: 5000, unit: '₹' },
      { id: 'expectedInflation', label: 'Expected Inflation Rate (%)', labelHi: 'महंगाई दर (% p.a)', defaultValue: 6, min: 4, max: 9, step: 0.5, unit: '%' }
    ],
    formulaExplanation: {
      formula: 'Corpus = रिटायरमेंट के समय का वार्षिक खर्च × 25 (4% सुरक्षित निकासी नियम)',
      explanationHi: 'रिटायरमेंट के समय महंगाई के कारण आपका मासिक खर्च बढ़ जाएगा। यह टूल 85 वर्ष की आयु तक के खर्चों की सुरक्षा सुनिश्चित करता है।',
      variables: [
        { symbol: 'Corpus', nameHi: 'कुल रिटायरमेंट फंड', desc: 'रिटायरमेंट के दिन बैंक में जरूरी पूंजी' }
      ]
    },
    assumptions: [
      'रिटायरमेंट के बाद जीवन प्रत्याशा 85 वर्ष मानी गई है।',
      'पोस्ट-रिटायरमेंट पोर्टफोलियो रिटर्न 8% वार्षिक माना गया है।'
    ]
  },
  {
    id: 'income-tax-estimator',
    slug: 'income-tax-estimator',
    name: 'Income Tax Estimator (New vs Old)',
    nameHi: 'इनकम टैक्स एस्टिमेटर (न्यू vs ओल्ड रिजीम)',
    description: 'Calculate and compare your income tax under New and Old Tax Regimes for FY 2024-25 / 2025-26.',
    descriptionHi: 'अपनी कुल सैलरी डालकर दोनों टैक्स व्यवस्थाओं की सीधी तुलना करें और जानें किसमें आपकी ज्यादा बचत होगी।',
    category: 'tax',
    iconName: 'ReceiptText',
    fields: [
      { id: 'annualIncome', label: 'Annual Gross Income (₹)', labelHi: 'वार्षिक कुल आय (Gross CTC) (₹)', defaultValue: 1200000, min: 300000, max: 10000000, step: 25000, unit: '₹' },
      { id: 'deduction80C', label: 'Section 80C Deductions (₹)', labelHi: 'धारा 80C निवेश (PF, PPF, ELSS) (₹)', defaultValue: 150000, min: 0, max: 150000, step: 10000, unit: '₹' },
      { id: 'deduction80D', label: 'Health Insurance (80D) (₹)', labelHi: 'हेल्थ इंश्योरेंस 80D (₹)', defaultValue: 25000, min: 0, max: 100000, step: 5000, unit: '₹' },
      { id: 'homeLoanInterest', label: 'Home Loan Interest (24b) (₹)', labelHi: 'होम लोन ब्याज 24(b) (₹)', defaultValue: 0, min: 0, max: 200000, step: 10000, unit: '₹' }
    ],
    formulaExplanation: {
      formula: 'टैक्स = टैक्स स्लैब अनुसार दरें + 4% हेल्थ एवं एजुकेशन सेस',
      explanationHi: 'न्यू रिजीम में ₹75,000 स्टैंडर्ड डिडक्शन और धारा 87A की ₹7 लाख तक की पूर्ण रिबेट शामिल है।',
      variables: [
        { symbol: 'Cess', nameHi: 'उपकर (4%)', desc: 'कुल आयकर पर 4% का अनिवार्य सेस' }
      ]
    },
    assumptions: [
      'न्यू टैक्स रिजीम में सैलरीड कर्मचारियों के लिए ₹75,000 स्टैंडर्ड डिडक्शन स्वतः लागू किया गया है।',
      'पुराने टैक्स रिजीम में ₹50,000 स्टैंडर्ड डिडक्शन और 80C/80D/होम लोन कटौतियां जोड़ी गई हैं।'
    ]
  }
];
