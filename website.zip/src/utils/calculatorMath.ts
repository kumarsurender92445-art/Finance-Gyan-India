export interface CalculationResult {
  primaryValue: number;
  primaryLabel: string;
  primaryLabelHi: string;
  secondaryValues: {
    label: string;
    labelHi: string;
    value: number;
    format: 'currency' | 'percent' | 'number' | 'years';
  }[];
  breakdown: {
    label: string;
    labelHi: string;
    value: number;
    percentage: number;
    color: string;
  }[];
  schedule?: {
    period: string | number;
    value1: number;
    value2: number;
    value3: number;
  }[];
  recommendationHi?: string;
}

export function formatINR(val: number): string {
  if (isNaN(val)) return '₹0';
  const rounded = Math.round(val);
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(rounded);
}

export function calculateCalculatorResult(id: string, values: Record<string, number>): CalculationResult {
  switch (id) {
    case 'sip-calculator': {
      const P = values.monthlyInvestment || 5000;
      const r = (values.expectedRate || 12) / 100 / 12;
      const n = (values.timePeriod || 10) * 12;
      
      const maturity = P * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
      const totalInvested = P * n;
      const totalReturns = maturity - totalInvested;

      return {
        primaryValue: maturity,
        primaryLabel: 'Expected Maturity Amount',
        primaryLabelHi: 'अनुमानित कुल फंड वैल्यू (मैच्योरिटी)',
        secondaryValues: [
          { label: 'Total Invested Amount', labelHi: 'कुल जमा की गई रकम', value: totalInvested, format: 'currency' },
          { label: 'Estimated Wealth Gain', labelHi: 'अनुमानित मुनाफा (वेल्थ गेन)', value: totalReturns, format: 'currency' },
          { label: 'Absolute Return', labelHi: 'कुल रिटर्न प्रतिशत', value: (totalReturns / totalInvested) * 100, format: 'percent' }
        ],
        breakdown: [
          { label: 'Invested Amount', labelHi: 'जमा मूलधन', value: totalInvested, percentage: (totalInvested / maturity) * 100, color: '#0F766E' },
          { label: 'Estimated Returns', labelHi: 'अनुमानित लाभ', value: totalReturns, percentage: (totalReturns / maturity) * 100, color: '#10B981' }
        ],
        recommendationHi: `यदि आप हर साल अपनी SIP में मात्र 10% की बढ़ोतरी (Step-up SIP) करते हैं, तो आपका अंतिम फंड लगभग 40% से 50% और अधिक हो सकता है।`
      };
    }

    case 'loan-emi-calculator':
    case 'home-loan-emi-calculator':
    case 'personal-loan-calculator': {
      const P = values.loanAmount || 1000000;
      const annualRate = values.interestRate || 9;
      const tenureYears = values.loanTenure || 5;
      
      const r = annualRate / 12 / 100;
      const n = tenureYears * 12;
      
      const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
      const totalPayment = emi * n;
      const totalInterest = totalPayment - P;

      return {
        primaryValue: emi,
        primaryLabel: 'Monthly EMI',
        primaryLabelHi: 'मासिक किस्त (Monthly EMI)',
        secondaryValues: [
          { label: 'Principal Loan Amount', labelHi: 'लोन मूलधन', value: P, format: 'currency' },
          { label: 'Total Interest Payable', labelHi: 'कुल देय ब्याज', value: totalInterest, format: 'currency' },
          { label: 'Total Repayment', labelHi: 'कुल भुगतान (मूलधन + ब्याज)', value: totalPayment, format: 'currency' }
        ],
        breakdown: [
          { label: 'Principal', labelHi: 'मूलधन', value: P, percentage: (P / totalPayment) * 100, color: '#1E3A8A' },
          { label: 'Total Interest', labelHi: 'कुल ब्याज', value: totalInterest, percentage: (totalInterest / totalPayment) * 100, color: '#F59E0B' }
        ],
        recommendationHi: `हर साल केवल 1 अतिरिक्त EMI चुकाने से आप अपने लोन की अवधि 3 से 4 साल कम कर सकते हैं और लाखों रुपये का ब्याज बचा सकते हैं।`
      };
    }

    case 'monthly-budget-calculator': {
      const income = values.monthlyIncome || 60000;
      const needsPct = values.needsRatio || 50;
      const wantsPct = values.wantsRatio || 30;
      const savingsPct = Math.max(0, 100 - needsPct - wantsPct);

      const needsAmount = (income * needsPct) / 100;
      const wantsAmount = (income * wantsPct) / 100;
      const savingsAmount = (income * savingsPct) / 100;

      return {
        primaryValue: savingsAmount,
        primaryLabel: 'Recommended Monthly Savings',
        primaryLabelHi: 'मासिक अनिवार्य बचत (20%)',
        secondaryValues: [
          { label: 'Needs Budget', labelHi: 'जरूरतें (किराया, राशन, बिल)', value: needsAmount, format: 'currency' },
          { label: 'Wants Budget', labelHi: 'इच्छाएं (शॉपिंग, आउटिंग)', value: wantsAmount, format: 'currency' },
          { label: 'Savings Budget', labelHi: 'बचत व निवेश (SIP/FD)', value: savingsAmount, format: 'currency' }
        ],
        breakdown: [
          { label: 'Needs (50%)', labelHi: 'जरूरतें', value: needsAmount, percentage: needsPct, color: '#0F766E' },
          { label: 'Wants (30%)', labelHi: 'इच्छाएं', value: wantsAmount, percentage: wantsPct, color: '#38BDF8' },
          { label: 'Savings (20%)', labelHi: 'बचत', value: savingsAmount, percentage: savingsPct, color: '#10B981' }
        ],
        recommendationHi: `वेतन आते ही सबसे पहले ₹${formatINR(savingsAmount)} को निवेश खाते या SIP में ऑटो-ट्रांसफर करें ("Pay Yourself First" नियम)।`
      };
    }

    case 'savings-goal-calculator': {
      const goal = values.targetAmount || 1000000;
      const saved = values.currentSavings || 100000;
      const years = values.yearsToGoal || 5;
      const r = (values.expectedReturn || 10) / 100 / 12;
      const n = years * 12;

      // Future value of existing savings
      const fvSaved = saved * Math.pow(1 + (values.expectedReturn || 10) / 100, years);
      const remainingGoal = Math.max(0, goal - fvSaved);
      
      const monthlyNeeded = remainingGoal > 0 
        ? remainingGoal / (((Math.pow(1 + r, n) - 1) / r) * (1 + r))
        : 0;

      return {
        primaryValue: monthlyNeeded,
        primaryLabel: 'Required Monthly Investment',
        primaryLabelHi: 'लक्ष्य पाने हेतु आवश्यक मासिक SIP/बचत',
        secondaryValues: [
          { label: 'Target Goal Amount', labelHi: 'कुल लक्ष्य राशि', value: goal, format: 'currency' },
          { label: 'Future Value of Current Savings', labelHi: 'मौजूदा बचत का भविष्य में मूल्य', value: fvSaved, format: 'currency' },
          { label: 'Remaining Shortfall to Fund', labelHi: 'शेष जुटाई जाने वाली रकम', value: remainingGoal, format: 'currency' }
        ],
        breakdown: [
          { label: 'Existing Savings Growth', labelHi: 'मौजूदा बचत की वृद्धि', value: fvSaved, percentage: Math.min(100, (fvSaved / goal) * 100), color: '#3B82F6' },
          { label: 'New Monthly Savings Needed', labelHi: 'नए मासिक निवेश से जरूरत', value: remainingGoal, percentage: Math.max(0, (remainingGoal / goal) * 100), color: '#10B981' }
        ]
      };
    }

    case 'fd-calculator': {
      const P = values.depositAmount || 100000;
      const r = (values.interestRate || 7.1) / 100;
      const t = values.tenureYears || 3;
      
      // Indian quarterly compounded FD
      const maturity = P * Math.pow(1 + r / 4, 4 * t);
      const totalInterest = maturity - P;

      return {
        primaryValue: maturity,
        primaryLabel: 'FD Maturity Amount',
        primaryLabelHi: 'मैच्योरिटी पर कुल राशि (₹)',
        secondaryValues: [
          { label: 'Principal Deposit', labelHi: 'जमा मूलधन', value: P, format: 'currency' },
          { label: 'Total Interest Earned', labelHi: 'कुल अर्जित ब्याज', value: totalInterest, format: 'currency' }
        ],
        breakdown: [
          { label: 'Deposit Principal', labelHi: 'मूलधन', value: P, percentage: (P / maturity) * 100, color: '#0F766E' },
          { label: 'Compound Interest', labelHi: 'ब्याज', value: totalInterest, percentage: (totalInterest / maturity) * 100, color: '#F59E0B' }
        ]
      };
    }

    case 'rd-calculator': {
      const P = values.monthlyDeposit || 3000;
      const r = (values.interestRate || 6.8) / 100;
      const t = values.tenureYears || 3;
      const n = t * 12;

      // Quarterly compounding RD approx for Indian banks
      let totalMaturity = 0;
      for (let i = 1; i <= n; i++) {
        const monthsRemaining = n - i + 1;
        totalMaturity += P * Math.pow(1 + r / 4, (4 * monthsRemaining) / 12);
      }
      const totalDeposited = P * n;
      const totalInterest = totalMaturity - totalDeposited;

      return {
        primaryValue: totalMaturity,
        primaryLabel: 'RD Maturity Amount',
        primaryLabelHi: 'आरडी मैच्योरिटी राशि (₹)',
        secondaryValues: [
          { label: 'Total Amount Deposited', labelHi: 'कुल जमा राशि', value: totalDeposited, format: 'currency' },
          { label: 'Total Interest Earned', labelHi: 'कुल ब्याज कमाई', value: totalInterest, format: 'currency' }
        ],
        breakdown: [
          { label: 'Deposited Amount', labelHi: 'जमा राशि', value: totalDeposited, percentage: (totalDeposited / totalMaturity) * 100, color: '#0F766E' },
          { label: 'Interest Earned', labelHi: 'ब्याज', value: totalInterest, percentage: (totalInterest / totalMaturity) * 100, color: '#10B981' }
        ]
      };
    }

    case 'compound-interest-calculator': {
      const P = values.principal || 200000;
      const r = (values.rate || 11) / 100;
      const t = values.years || 10;
      
      const maturity = P * Math.pow(1 + r, t);
      const interest = maturity - P;

      return {
        primaryValue: maturity,
        primaryLabel: 'Total Accumulated Value',
        primaryLabelHi: 'कुल संचित राशि (A)',
        secondaryValues: [
          { label: 'Initial Principal', labelHi: 'प्रारंभिक मूलधन', value: P, format: 'currency' },
          { label: 'Compound Interest', labelHi: 'कंपाउंड ब्याज मुनाफा', value: interest, format: 'currency' },
          { label: 'Growth Multiplier', labelHi: 'पैसे में कुल गुना वृद्धि', value: maturity / P, format: 'number' }
        ],
        breakdown: [
          { label: 'Principal', labelHi: 'मूलधन', value: P, percentage: (P / maturity) * 100, color: '#1E3A8A' },
          { label: 'Interest', labelHi: 'चक्रवृद्धि ब्याज', value: interest, percentage: (interest / maturity) * 100, color: '#10B981' }
        ]
      };
    }

    case 'inflation-calculator': {
      const current = values.currentExpenses || 50000;
      const infl = (values.inflationRate || 6) / 100;
      const years = values.yearsAhead || 15;
      
      const futureCost = current * Math.pow(1 + infl, years);
      const purchasingPowerOfCurrentMoney = current / Math.pow(1 + infl, years);

      return {
        primaryValue: futureCost,
        primaryLabel: 'Future Cost of Same Expense',
        primaryLabelHi: 'भविष्य में इस खर्च की अनुमानित लागत',
        secondaryValues: [
          { label: 'Current Cost Today', labelHi: 'आज का वास्तविक खर्च', value: current, format: 'currency' },
          { label: 'Inflation Increase Amount', labelHi: 'महंगाई से बढ़ा हुआ अतिरिक्त बोझ', value: futureCost - current, format: 'currency' },
          { label: 'Future Value of Today ₹' + current, labelHi: 'आज के ₹' + current + ' की भविष्य में क्रय शक्ति', value: purchasingPowerOfCurrentMoney, format: 'currency' }
        ],
        breakdown: [
          { label: 'Base Cost', labelHi: 'आज की लागत', value: current, percentage: (current / futureCost) * 100, color: '#0F766E' },
          { label: 'Inflation Erosion', labelHi: 'महंगाई का प्रभाव', value: futureCost - current, percentage: ((futureCost - current) / futureCost) * 100, color: '#EF4444' }
        ],
        recommendationHi: `महंगाई से बचने के लिए अपने पैसे को केवल बचत खाते या कम ब्याज वाली FD में न रखें। इक्विटी म्यूचुअल फंड या SIP जैसे एसेट क्लास मुद्रास्फीति को हराने में मददगार होते हैं।`
      };
    }

    case 'retirement-corpus-calculator': {
      const currentAge = values.currentAge || 30;
      const retAge = values.retirementAge || 60;
      const expenseNow = values.monthlyExpenseNow || 40000;
      const infl = (values.expectedInflation || 6) / 100;
      
      const yearsToRet = Math.max(1, retAge - currentAge);
      const monthlyExpenseAtRet = expenseNow * Math.pow(1 + infl, yearsToRet);
      const annualExpenseAtRet = monthlyExpenseAtRet * 12;
      
      // Standard 4% safe withdrawal rule (25x annual expenses at retirement)
      const corpusNeeded = annualExpenseAtRet * 25;
      
      // Monthly SIP needed to reach corpus at 12% return
      const r = 0.12 / 12;
      const n = yearsToRet * 12;
      const sipNeeded = corpusNeeded / (((Math.pow(1 + r, n) - 1) / r) * (1 + r));

      return {
        primaryValue: corpusNeeded,
        primaryLabel: 'Required Retirement Corpus',
        primaryLabelHi: 'रिटायरमेंट के समय आवश्यक कुल फंड (Corpus)',
        secondaryValues: [
          { label: 'Monthly Expenses at Age ' + retAge, labelHi: 'रिटायरमेंट पर मासिक खर्च (महंगाई सहित)', value: monthlyExpenseAtRet, format: 'currency' },
          { label: 'Monthly SIP Needed From Today', labelHi: 'आज से आवश्यक मासिक SIP (12% रिटर्न पर)', value: sipNeeded, format: 'currency' },
          { label: 'Years to Retirement', labelHi: 'रिटायरमेंट में शेष वर्ष', value: yearsToRet, format: 'years' }
        ],
        breakdown: [
          { label: 'Annual Expense Requirement', labelHi: 'सालाना खर्च जरूरत', value: annualExpenseAtRet, percentage: 4, color: '#38BDF8' },
          { label: '25-Year Corpus Capital', labelHi: 'सुरक्षित कुल पूंजी', value: corpusNeeded, percentage: 96, color: '#0F766E' }
        ]
      };
    }

    case 'income-tax-estimator': {
      const grossIncome = values.annualIncome || 1200000;
      const deduction80C = Math.min(150000, values.deduction80C || 0);
      const deduction80D = values.deduction80D || 0;
      const homeLoanInterest = Math.min(200000, values.homeLoanInterest || 0);

      // 1. New Tax Regime (FY 2024-25 / 2025-26 with standard deduction of 75,000)
      const stdDedNew = 75000;
      const taxableNew = Math.max(0, grossIncome - stdDedNew);
      let taxNew = 0;
      if (taxableNew <= 700000) {
        // Section 87A rebate gives zero tax up to 7 lakh taxable income
        taxNew = 0;
      } else {
        if (taxableNew > 300000) {
          taxNew += Math.min(400000, taxableNew - 300000) * 0.05;
        }
        if (taxableNew > 700000) {
          taxNew += Math.min(300000, taxableNew - 700000) * 0.10;
        }
        if (taxableNew > 1000000) {
          taxNew += Math.min(200000, taxableNew - 1000000) * 0.15;
        }
        if (taxableNew > 1200000) {
          taxNew += Math.min(300000, taxableNew - 1200000) * 0.20;
        }
        if (taxableNew > 1500000) {
          taxNew += (taxableNew - 1500000) * 0.30;
        }
      }
      const totalTaxNew = taxNew > 0 ? taxNew * 1.04 : 0; // 4% cess

      // 2. Old Tax Regime
      const stdDedOld = 50000;
      const totalDeductionsOld = stdDedOld + deduction80C + deduction80D + homeLoanInterest;
      const taxableOld = Math.max(0, grossIncome - totalDeductionsOld);
      let taxOld = 0;
      if (taxableOld <= 500000) {
        taxOld = 0; // 87A rebate up to 5 lakh
      } else {
        if (taxableOld > 250000) {
          taxOld += Math.min(250000, taxableOld - 250000) * 0.05;
        }
        if (taxableOld > 500000) {
          taxOld += Math.min(500000, taxableOld - 500000) * 0.20;
        }
        if (taxableOld > 1000000) {
          taxOld += (taxableOld - 1000000) * 0.30;
        }
      }
      const totalTaxOld = taxOld > 0 ? taxOld * 1.04 : 0;

      const diff = Math.abs(totalTaxNew - totalTaxOld);
      const isNewBetter = totalTaxNew <= totalTaxOld;

      return {
        primaryValue: isNewBetter ? totalTaxNew : totalTaxOld,
        primaryLabel: isNewBetter ? 'Tax Payable Under New Regime (Best Choice)' : 'Tax Payable Under Old Regime (Best Choice)',
        primaryLabelHi: isNewBetter ? 'न्यू टैक्स रिजीम में देय टैक्स (सर्वश्रेष्ठ विकल्प)' : 'पुराने टैक्स रिजीम में देय टैक्स (सर्वश्रेष्ठ विकल्प)',
        secondaryValues: [
          { label: 'New Tax Regime Total Tax', labelHi: 'न्यू टैक्स रिजीम में कुल टैक्स', value: totalTaxNew, format: 'currency' },
          { label: 'Old Tax Regime Total Tax', labelHi: 'पुराने टैक्स रिजीम में कुल टैक्स', value: totalTaxOld, format: 'currency' },
          { label: 'Direct Tax Savings', labelHi: 'बेहतर विकल्प चुनकर टैक्स बचत', value: diff, format: 'currency' }
        ],
        breakdown: [
          { label: 'New Regime Tax', labelHi: 'न्यू रिजीम टैक्स', value: totalTaxNew, percentage: totalTaxNew + totalTaxOld > 0 ? (totalTaxNew / (totalTaxNew + totalTaxOld)) * 100 : 50, color: '#0F766E' },
          { label: 'Old Regime Tax', labelHi: 'पुराना रिजीम टैक्स', value: totalTaxOld, percentage: totalTaxNew + totalTaxOld > 0 ? (totalTaxOld / (totalTaxNew + totalTaxOld)) * 100 : 50, color: '#F59E0B' }
        ],
        recommendationHi: isNewBetter 
          ? `आपके लिए "न्यू टैक्स रिजीम" ज्यादा फायदेमंद है! आप हर साल ₹${formatINR(diff)} बचा रहे हैं।`
          : `आपके लिए "पुराना टैक्स रिजीम" ज्यादा फायदेमंद है क्योंकि आपके पास पर्याप्त 80C, 80D और होम लोन कटौतियां हैं। आप ₹${formatINR(diff)} बचा रहे हैं।`
      };
    }

    default:
      return {
        primaryValue: 0,
        primaryLabel: 'Result',
        primaryLabelHi: 'परिणाम',
        secondaryValues: [],
        breakdown: []
      };
  }
}
