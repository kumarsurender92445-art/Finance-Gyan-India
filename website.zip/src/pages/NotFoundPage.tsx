import React from 'react';
import { Home, Search, Calculator, ArrowRight } from 'lucide-react';
import { Language } from '../types';

interface NotFoundPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const NotFoundPage: React.FC<NotFoundPageProps> = ({ navigate, lang }) => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16 text-center space-y-6">
      <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-400 font-mono font-extrabold text-3xl">
        404
      </div>

      <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
        {lang === 'hi' ? 'पृष्ठ नहीं मिला (Page Not Found)' : 'Page Not Found'}
      </h1>

      <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 max-w-md mx-auto leading-relaxed">
        {lang === 'hi'
          ? 'आप जिस पृष्ठ को खोज रहे हैं, वह शायद स्थानांतरित कर दिया गया है या उसका लिंक बदल गया है।'
          : 'The page you are looking for might have been moved or removed.'}
      </p>

      <div className="pt-4 flex flex-wrap items-center justify-center gap-3">
        <button
          onClick={() => navigate('/')}
          className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white text-xs sm:text-sm font-semibold rounded-lg transition-colors flex items-center gap-2"
        >
          <Home className="w-4 h-4" />
          <span>{lang === 'hi' ? 'होम पेज पर जाएं' : 'Return Home'}</span>
        </button>

        <button
          onClick={() => navigate('/search')}
          className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs sm:text-sm font-semibold rounded-lg transition-colors flex items-center gap-2"
        >
          <Search className="w-4 h-4" />
          <span>{lang === 'hi' ? 'सामग्री खोजें' : 'Search Guides'}</span>
        </button>

        <button
          onClick={() => navigate('/calculators')}
          className="px-5 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 text-xs sm:text-sm font-semibold rounded-lg transition-colors flex items-center gap-2"
        >
          <Calculator className="w-4 h-4" />
          <span>{lang === 'hi' ? 'वित्तीय कैलकुलेटर' : 'Calculators'}</span>
        </button>
      </div>
    </div>
  );
};
