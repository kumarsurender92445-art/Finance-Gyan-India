import React, { useState, useEffect } from 'react';
import { Search, ArrowRight, Calculator } from 'lucide-react';
import { ARTICLES } from '../data/articles';
import { CALCULATORS } from '../data/calculators';
import { CATEGORIES } from '../data/categories';
import { ArticleCard } from '../components/ArticleCard';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Language } from '../types';

interface SearchPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const SearchPage: React.FC<SearchPageProps> = ({ navigate, lang }) => {
  const [query, setQuery] = useState('');
  const [selectedCat, setSelectedCat] = useState('all');

  useEffect(() => {
    // Read query from URL if available
    const urlParams = new URLSearchParams(window.location.search);
    const q = urlParams.get('q');
    if (q) setQuery(q);
  }, []);

  const normalized = query.trim().toLowerCase();

  const matchingArticles = ARTICLES.filter((a) => {
    if (selectedCat !== 'all' && a.categorySlug !== selectedCat) return false;
    if (!normalized) return true;
    return (
      a.title.toLowerCase().includes(normalized) ||
      a.titleHi.toLowerCase().includes(normalized) ||
      a.excerpt.toLowerCase().includes(normalized) ||
      a.excerptHi.toLowerCase().includes(normalized) ||
      a.tags.some((t) => t.toLowerCase().includes(normalized))
    );
  });

  const matchingCalculators = normalized
    ? CALCULATORS.filter(
        (c) =>
          c.name.toLowerCase().includes(normalized) ||
          c.nameHi.toLowerCase().includes(normalized) ||
          c.description.toLowerCase().includes(normalized) ||
          c.descriptionHi.toLowerCase().includes(normalized)
      )
    : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'सर्च परिणाम' : 'Search' }]} navigate={navigate} />

      {/* Search Header */}
      <div className="mt-4 mb-8 max-w-3xl">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          {lang === 'hi' ? 'खोजें और जानें (Search Finance Guides)' : 'Search Finance Guides'}
        </h1>
        <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
          {lang === 'hi'
            ? 'किसी भी विषय, लोन, टैक्स नियम या म्यूचुअल फंड पर हमारे प्रमाणित आलेख और कैलकुलेटर खोजें।'
            : 'Find articles, formulas, and calculators matching your keywords.'}
        </p>

        {/* Search Bar */}
        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={lang === 'hi' ? 'कीवर्ड लिखें, जैसे: SIP, EMI, Tax, CIBIL...' : 'Enter keywords: SIP, EMI, Tax...'}
              className="w-full pl-11 pr-4 py-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          <select
            value={selectedCat}
            onChange={(e) => setSelectedCat(e.target.value)}
            className="px-4 py-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-xs sm:text-sm text-slate-900 dark:text-white focus:outline-none"
          >
            <option value="all">{lang === 'hi' ? 'सभी श्रेणियां' : 'All Categories'}</option>
            {CATEGORIES.map((c) => (
              <option key={c.id} value={c.slug}>
                {lang === 'hi' ? c.nameHi : c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Calculators Results (if query matches any tool) */}
      {matchingCalculators.length > 0 && (
        <div className="mb-10">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3 flex items-center gap-1.5">
            <Calculator className="w-4 h-4 text-teal-600" />
            <span>{lang === 'hi' ? 'मिलते-जुलते कैलकुलेटर टूल्स' : 'Matching Calculators'}</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {matchingCalculators.map((calc) => (
              <div
                key={calc.id}
                onClick={() => navigate(`/calculator/${calc.slug}`)}
                className="p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-teal-500 cursor-pointer flex justify-between items-center group"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-700">
                    {lang === 'hi' ? calc.nameHi : calc.name}
                  </h3>
                  <p className="text-xs text-slate-500 line-clamp-1">{calc.descriptionHi}</p>
                </div>
                <ArrowRight className="w-4 h-4 text-teal-600 ml-2 group-hover:translate-x-1 transition-transform shrink-0" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Articles Results */}
      <div>
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-200 dark:border-slate-800">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            {lang === 'hi' ? `आलेख परिणाम (${matchingArticles.length})` : `Articles (${matchingArticles.length})`}
          </h2>
          {query && (
            <span className="text-xs text-slate-500">
              {lang === 'hi' ? `"${query}" के लिए` : `for "${query}"`}
            </span>
          )}
        </div>

        {matchingArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {matchingArticles.map((art) => (
              <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
            ))}
          </div>
        ) : (
          <div className="p-12 text-center bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <p className="text-slate-600 dark:text-slate-300 text-sm">
              {lang === 'hi'
                ? 'आपके खोजे गए शब्द से कोई परिणाम नहीं मिला। कृपया सरल शब्द या श्रेणी चुनकर प्रयास करें।'
                : 'No articles matched your criteria. Try different search terms or select All Categories.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
