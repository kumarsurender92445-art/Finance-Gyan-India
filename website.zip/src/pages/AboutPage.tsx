import React from 'react';
import { ShieldCheck, Target, HeartHandshake, Award } from 'lucide-react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { AUTHORS } from '../data/authors';
import { Language } from '../types';

interface AboutPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const AboutPage: React.FC<AboutPageProps> = ({ navigate, lang }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'हमारे बारे में' : 'About Us' }]} navigate={navigate} />

      {/* Hero */}
      <div className="mt-4 mb-12 max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
          {lang === 'hi' ? 'हमारा मिशन एवं विजन' : 'Our Mission'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? 'Finance Gyan India: भारत का पारदर्शी वित्तीय शिक्षा मंच' : 'About Finance Gyan India'}
        </h1>
        <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
          {lang === 'hi'
            ? 'हमारा उद्देश्य प्रत्येक भारतीय परिवार, वेतनभोगी युवा, छात्र और छोटे कारोबारी तक सरल, स्पष्ट और बिना किसी जटिलता के प्रामाणिक वित्तीय ज्ञान पहुंचाना है।'
            : 'Demystifying personal finance, mutual fund investments, banking, and tax laws for every Indian citizen.'}
        </p>
      </div>

      {/* Core Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950 flex items-center justify-center text-teal-700 dark:text-teal-400 font-bold mb-4">
            <Target className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {lang === 'hi' ? '100% निष्पक्ष संपादकीय' : '100% Unbiased Content'}
          </h3>
          <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {lang === 'hi'
              ? 'हम किसी भी बैंक या म्यूचुअल फंड कंपनी से कमीशन के लिए पक्षपाती समीक्षा नहीं करते। हमारे सभी आलेख केवल पाठक के लाभ को ध्यान में रखकर तैयार किए जाते हैं।'
              : 'Our editorial team operates independently. We never endorse poor products for commission.'}
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950 flex items-center justify-center text-teal-700 dark:text-teal-400 font-bold mb-4">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {lang === 'hi' ? 'RBI व SEBI नियमों के अनुरूप' : 'Regulatory Grounding'}
          </h3>
          <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {lang === 'hi'
              ? 'सभी वित्तीय आंकड़े, नियम और टैक्स स्लैब भारतीय रिजर्व बैंक (RBI), सेबी (SEBI) और आयकर विभाग के आधिकारिक परिपत्रों से सत्यापित होते हैं।'
              : 'Grounded in verifiable regulatory disclosures from official government authorities.'}
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800">
          <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950 flex items-center justify-center text-teal-700 dark:text-teal-400 font-bold mb-4">
            <HeartHandshake className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {lang === 'hi' ? 'सरल व व्यावहारिक भाषा' : 'Accessible in Plain Hindi'}
          </h3>
          <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            {lang === 'hi'
              ? 'जटिल वित्तीय शब्दों को रोजमर्रा के उदाहरणों और तालिकाओं के साथ समझाया गया है ताकि कोई भी अपनी पहली SIP या टैक्स प्लानिंग स्वयं कर सके।'
              : 'Translating complex financial jargon into practical, actionable steps for everyday earners.'}
          </p>
        </div>
      </div>

      {/* Editorial Team */}
      <div className="mb-16">
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight mb-8">
          {lang === 'hi' ? 'हमारी संपादकीय टीम' : 'Meet Our Editorial Leaders'}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {AUTHORS.map((author) => (
            <div
              key={author.id}
              onClick={() => navigate(`/author/${author.id}`)}
              className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 cursor-pointer hover:border-teal-500 transition-all"
            >
              <img
                src={author.avatar}
                alt={author.name}
                className="w-16 h-16 rounded-full object-cover border border-slate-200 mb-4"
              />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {lang === 'hi' ? author.nameHi : author.name}
              </h3>
              <p className="text-xs text-teal-700 dark:text-teal-400 font-semibold mt-0.5">
                {lang === 'hi' ? author.roleHi : author.role}
              </p>
              <p className="mt-2 text-xs text-slate-500 line-clamp-3 leading-relaxed">
                {lang === 'hi' ? author.bioHi : author.bio}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
