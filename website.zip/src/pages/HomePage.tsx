import React, { useState } from 'react';
import { Search, ArrowRight, ShieldCheck, CheckCircle2, Calculator, TrendingUp, Sparkles, HelpCircle } from 'lucide-react';
import { ARTICLES } from '../data/articles';
import { CATEGORIES } from '../data/categories';
import { CALCULATORS } from '../data/calculators';
import { AUTHORS } from '../data/authors';
import { ArticleCard } from '../components/ArticleCard';
import { AdContainer } from '../components/AdContainer';
import { Language } from '../types';

interface HomePageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const HomePage: React.FC<HomePageProps> = ({ navigate, lang }) => {
  const [heroSearch, setHeroSearch] = useState('');

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (heroSearch.trim()) {
      navigate(`/search?q=${encodeURIComponent(heroSearch.trim())}`);
    }
  };

  const featuredArticle = ARTICLES.find((a) => a.isFeatured) || ARTICLES[0];
  const secondaryFeatured = ARTICLES.filter((a) => a.id !== featuredArticle.id).slice(0, 2);
  const latestArticles = ARTICLES.slice(0, 4);

  // Grouped category articles
  const bankingAndLoanArticles = ARTICLES.filter((a) => ['banking', 'loans-emi', 'credit-cards'].includes(a.categorySlug));
  const savingAndBudgetArticles = ARTICLES.filter((a) => ['saving-money', 'budget-planning', 'personal-finance'].includes(a.categorySlug));
  const investmentArticles = ARTICLES.filter((a) => ['sip-investing', 'mutual-funds', 'stock-market'].includes(a.categorySlug));
  const taxAndGovtArticles = ARTICLES.filter((a) => ['income-tax', 'govt-schemes', 'retirement'].includes(a.categorySlug));

  return (
    <div className="space-y-16 pb-12">
      {/* 1. Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-teal-950/10 via-slate-50 to-white dark:from-slate-900 dark:via-slate-900 dark:to-slate-950 border-b border-slate-200 dark:border-slate-800 pt-10 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Headlines & Search */}
            <div className="lg:col-span-7 space-y-6">
              {/* Clean unboxed domain metadata tag */}
              <div className="flex items-center gap-2 text-xs font-semibold text-teal-800 dark:text-teal-400">
                <span>भारत का निष्पक्ष वित्तीय शिक्षा पोर्टल</span>
                <span aria-hidden="true">·</span>
                <span>प्रमाणित विशेषज्ञ द्वारा समीक्षित</span>
              </div>

              {/* Exact requested headline */}
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-[1.18] text-balance">
                पैसों की सही जानकारी, बेहतर भविष्य की तैयारी
              </h1>

              {/* 2. Short Introduction to the finance blog */}
              <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                {lang === 'hi'
                  ? 'Finance Gyan India में आपका स्वागत है। यहाँ भारतीय वेतनभोगी कर्मचारियों, छात्रों, शुरुआती निवेशकों और छोटे व्यापार मालिकों के लिए म्यूचुअल फंड, SIP, होम लोन, 800+ सिबिल स्कोर और इनकम टैक्स नियमों की 100% प्रामाणिक व आसान हिंदी गाइड उपलब्ध है।'
                  : 'Welcome to Finance Gyan India. Your trusted portal for practical personal finance, mutual funds, SIP compounding, loan EMI planning, and income tax strategies tailored for India.'}
              </p>

              {/* 3. Search articles section */}
              <form onSubmit={handleHeroSearch} className="relative max-w-xl">
                <div className="relative flex items-center shadow-sm rounded-xl overflow-hidden border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800">
                  <Search className="w-5 h-5 text-slate-400 ml-4 shrink-0" />
                  <input
                    type="text"
                    value={heroSearch}
                    onChange={(e) => setHeroSearch(e.target.value)}
                    placeholder={lang === 'hi' ? 'खोजें: जैसे SIP कैसे शुरू करें, न्यू टैक्स रिजीम, EMI कैलकुलेटर...' : 'Search: e.g. SIP guide, New Tax regime, EMI...'}
                    className="w-full px-4 py-3.5 bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="px-5 py-3.5 bg-teal-700 hover:bg-teal-800 text-white font-medium text-xs sm:text-sm transition-colors shrink-0"
                  >
                    {lang === 'hi' ? 'सर्च करें' : 'Search'}
                  </button>
                </div>
              </form>

              {/* Quick Topic Shortcuts */}
              <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-slate-600 dark:text-slate-400">
                <span className="font-semibold">{lang === 'hi' ? 'त्वरित विषय:' : 'Trending:'}</span>
                {['SIP Guide', 'New vs Old Tax', 'Loan Prepayment', 'Emergency Fund', '800 CIBIL'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => navigate(`/search?q=${encodeURIComponent(tag)}`)}
                    className="px-2.5 py-1 rounded bg-slate-200/70 dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-teal-100 dark:hover:bg-teal-900/40 hover:text-teal-900 dark:hover:text-teal-300 transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>

            {/* Right Column: Hero Image Asset */}
            <div className="lg:col-span-5">
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-xl bg-slate-100 dark:bg-slate-800">
                <img
                  src="/src/assets/images/hero_finance_india_1792828932053.jpg"
                  alt="Indian finance professional learning about investments and planning in rupees"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover"
                />
                <div className="p-4 bg-white/95 dark:bg-slate-900/95 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                    <span className="font-semibold text-teal-700 dark:text-teal-400">12+ लाइव कैलकुलेटर</span>
                    <span aria-hidden="true">·</span>
                    <span>16 वित्तीय श्रेणियां</span>
                    <span aria-hidden="true">·</span>
                    <span>100% निशुल्क ज्ञान</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Featured Finance Guides */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 pb-3 border-b border-slate-200 dark:border-slate-800">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
              {lang === 'hi' ? 'विशेष संपादकीय चयन' : 'Editor’s Choice'}
            </span>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
              {lang === 'hi' ? 'फीचर्ड फाइनेंस गाइड्स' : 'Featured Finance Guides'}
            </h2>
          </div>
          <button
            onClick={() => navigate('/blog')}
            className="mt-2 sm:mt-0 text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1"
          >
            <span>{lang === 'hi' ? 'सभी ब्लॉग लेख देखें' : 'View All Articles'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Featured Card */}
        <div className="space-y-6">
          <ArticleCard article={featuredArticle} navigate={navigate} lang={lang} layout="featured" />

          {/* Secondary Featured Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {secondaryFeatured.map((art) => (
              <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
            ))}
          </div>
        </div>
      </section>

      {/* AdSense Unit #1 */}
      <AdContainer slotId="homepage-middle-slot-1" format="horizontal" />

      {/* 5. Latest Articles Section & Popular Sidebar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Column: Latest Articles */}
          <div className="lg:col-span-8">
            <div className="flex items-center justify-between mb-6 pb-2 border-b border-slate-200 dark:border-slate-800">
              <h2 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
                {lang === 'hi' ? 'ताज़ा वित्तीय लेख' : 'Latest Financial Articles'}
              </h2>
              <button
                onClick={() => navigate('/latest')}
                className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline"
              >
                {lang === 'hi' ? 'और देखें →' : 'See more →'}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {latestArticles.map((art) => (
                <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
              ))}
            </div>
          </div>

          {/* Sidebar Column: Popular Articles & Quick Calculators */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white dark:bg-slate-800/80 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3 pb-2 border-b border-slate-100 dark:border-slate-700">
                {lang === 'hi' ? 'सबसे ज्यादा पढ़े गए लेख' : 'Most Popular Guides'}
              </h3>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {ARTICLES.map((art) => (
                  <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="compact" />
                ))}
              </div>
            </div>

            {/* Quick Calculator Widget in Sidebar */}
            <div className="bg-slate-900 text-white p-5 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <Calculator className="w-4 h-4 text-teal-400" />
                <h4 className="text-sm font-bold tracking-tight">
                  {lang === 'hi' ? 'त्वरित SIP कैलकुलेटर' : 'Quick SIP Estimator'}
                </h4>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {lang === 'hi'
                  ? '₹5,000 प्रति माह 10 साल में 12% पर बन सकते हैं लगभग ₹11.6 लाख!'
                  : '₹5,000/mo at 12% in 10 years grows to approx ₹11.6 Lakhs!'}
              </p>
              <button
                onClick={() => navigate('/calculator/sip-calculator')}
                className="mt-4 w-full py-2 bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold rounded-lg transition-colors text-center"
              >
                {lang === 'hi' ? 'अपना रिटर्न खुद निकालें →' : 'Calculate Your Returns →'}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. All 16 Category Cards Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
            {lang === 'hi' ? 'ज्ञान का वर्गीकरण' : 'Knowledge Hub'}
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
            {lang === 'hi' ? 'सभी वित्तीय विषय व श्रेणियां' : 'All Finance Categories'}
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            {lang === 'hi'
              ? 'बचत, टैक्स, लोन, शेयर बाजार और सरकारी योजनाओं पर गहन और व्यावहारिक गाइड।'
              : 'Browse structured guides on banking, taxation, loans, mutual funds, and government schemes.'}
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => navigate(`/category/${cat.slug}`)}
              className="p-4 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 hover:border-teal-500/50 hover:shadow-sm text-left transition-all group"
            >
              <div className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                {lang === 'hi' ? cat.nameHi : cat.name}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                {lang === 'hi' ? cat.descriptionHi : cat.description}
              </div>
              <div className="mt-3 text-[11px] font-medium text-teal-700 dark:text-teal-400">
                {cat.articleCount} {lang === 'hi' ? 'लेख' : 'articles'} →
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* 7. Deep-Dive Section: Personal Finance & Banking / Loans */}
      <section className="bg-slate-100/70 dark:bg-slate-900/50 py-12 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          {/* Section A: Banking, Loans, and Credit Cards */}
          <div>
            <div className="flex items-center justify-between mb-6 pb-2 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  {lang === 'hi' ? 'बैंकिंग, लोन एवं क्रेडिट कार्ड' : 'Banking, Loans & Credit Cards'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {lang === 'hi' ? 'कर्ज के जाल से कैसे बचें और कम ब्याज दर पर होम लोन कैसे पाएं' : 'Smart borrowing, CIBIL score recovery, and loan prepayment'}
                </p>
              </div>
              <button
                onClick={() => navigate('/category/loans-emi')}
                className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline"
              >
                {lang === 'hi' ? 'सभी देखें →' : 'Explore →'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bankingAndLoanArticles.map((art) => (
                <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
              ))}
            </div>
          </div>

          {/* Section B: Investment, Tax & Government Schemes */}
          <div>
            <div className="flex items-center justify-between mb-6 pb-2 border-b border-slate-200 dark:border-slate-800">
              <div>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">
                  {lang === 'hi' ? 'निवेश शिक्षा एवं सरकारी योजनाएं' : 'Investing Education & Govt Schemes'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {lang === 'hi' ? 'SIP, इंडेक्स फंड, टैक्स सेविंग और सुकन्या समृद्धि योजना' : 'Wealth compounding and safe government schemes'}
                </p>
              </div>
              <button
                onClick={() => navigate('/category/sip-investing')}
                className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline"
              >
                {lang === 'hi' ? 'सभी देखें →' : 'Explore →'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...investmentArticles, ...taxAndGovtArticles].slice(0, 3).map((art) => (
                <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 8. Financial Calculators Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 pb-3 border-b border-slate-200 dark:border-slate-800">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
              {lang === 'hi' ? 'सटीक गणना टूल्स' : 'Interactive Math Engines'}
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
              {lang === 'hi' ? '12+ लाइव वित्तीय कैलकुलेटर' : '12+ Live Financial Calculators'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {lang === 'hi'
                ? 'अपने वित्तीय लक्ष्यों, ईएमआई, रिटायरमेंट और टैक्स की गणना कुछ सेकंडों में करें।'
                : 'Free, instant calculators with Indian formulas and clear visual breakdown.'}
            </p>
          </div>
          <button
            onClick={() => navigate('/calculators')}
            className="mt-3 sm:mt-0 px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white text-xs font-semibold rounded-lg transition-colors"
          >
            {lang === 'hi' ? 'सभी 12 कैलकुलेटर देखें' : 'View All 12 Tools'}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {CALCULATORS.map((calc) => (
            <div
              key={calc.id}
              onClick={() => navigate(`/calculator/${calc.slug}`)}
              className="p-5 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-teal-50 dark:bg-teal-950 flex items-center justify-center text-teal-700 dark:text-teal-300 font-bold mb-3">
                  <Calculator className="w-5 h-5" />
                </div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                  {lang === 'hi' ? calc.nameHi : calc.name}
                </h3>
                <p className="mt-1.5 text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed">
                  {lang === 'hi' ? calc.descriptionHi : calc.description}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs text-teal-700 dark:text-teal-400 font-semibold">
                <span>{lang === 'hi' ? 'गणना करें' : 'Calculate'}</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 9. Expert-Reviewed Educational Content Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white dark:bg-slate-800/90 rounded-2xl p-6 sm:p-10 border border-slate-200 dark:border-slate-800">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 dark:text-teal-400 uppercase tracking-wider mb-2">
              <ShieldCheck className="w-4 h-4" />
              <span>{lang === 'hi' ? 'संपादकीय सत्यनिष्ठा एवं विशेषज्ञ समीक्षा' : 'Editorial Integrity'}</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
              {lang === 'hi'
                ? 'प्रमाणित वित्तीय विशेषज्ञों द्वारा जांची-परखी गई सामग्री'
                : 'Content Reviewed by Certified Financial Professionals'}
            </h2>
            <p className="mt-3 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {lang === 'hi'
                ? 'Finance Gyan India पर प्रकाशित प्रत्येक मार्गदर्शिका को सर्टिफाइड फाइनेंशियल प्लानर्स (CFP®), चार्टर्ड अकाउंटेंट्स (CA) और वित्तीय शोधकर्ताओं द्वारा भारतीय रिजर्व बैंक (RBI), SEBI, और आयकर विभाग के आधिकारिक दिशा-निर्देशों के आधार पर तैयार किया जाता है। हम भ्रामक दावों, गैर-प्रामाणिक स्कीमों और झूठे विज्ञापनों से पूरी तरह मुक्त हैं।'
                : 'Every article is researched and reviewed against regulatory frameworks from RBI, SEBI, and CBDT. We do not promote get-rich-quick schemes, false promises, or fabricated financial performance.'}
            </p>
          </div>

          <div className="mt-8 grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-slate-100 dark:border-slate-700">
            {AUTHORS.map((author) => (
              <div
                key={author.id}
                onClick={() => navigate(`/author/${author.id}`)}
                className="flex items-center gap-3 cursor-pointer group"
              >
                <img
                  src={author.avatar}
                  alt={author.name}
                  className="w-12 h-12 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                />
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                    {lang === 'hi' ? author.nameHi : author.name}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-1">{author.credentials[0]}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AdSense Unit #2 */}
      <AdContainer slotId="homepage-bottom-slot-2" format="horizontal" />
    </div>
  );
};
