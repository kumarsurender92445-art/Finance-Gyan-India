import React from 'react';
import { TrendingUp, Sparkles } from 'lucide-react';
import { ARTICLES } from '../data/articles';
import { ArticleCard } from '../components/ArticleCard';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Language } from '../types';

interface TrendingPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const TrendingPage: React.FC<TrendingPageProps> = ({ navigate, lang }) => {
  const trending = ARTICLES.filter((a) => a.isTrending);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'ट्रेंडिंग लेख' : 'Trending Articles' }]} navigate={navigate} />

      <div className="mt-4 mb-8 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
          <TrendingUp className="w-4 h-4" />
          <span>{lang === 'hi' ? 'पाठकों की पहली पसंद' : 'Most Popular Now'}</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? 'ट्रेंडिंग वित्तीय लेख एवं विश्लेषण' : 'Trending Financial Guides'}
        </h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          {lang === 'hi'
            ? 'इस सप्ताह सबसे अधिक पढ़े जा रहे पर्सनल फाइनेंस, लोन प्रीपेमेंट और SIP रणनीतियों के आलेख।'
            : 'Explore what other readers across India are learning today.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {trending.map((art) => (
          <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
        ))}
      </div>
    </div>
  );
};
