import React, { useState } from 'react';
import { ARTICLES } from '../data/articles';
import { CATEGORIES } from '../data/categories';
import { ArticleCard } from '../components/ArticleCard';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { AdContainer } from '../components/AdContainer';
import { Language } from '../types';

interface BlogPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const BlogPage: React.FC<BlogPageProps> = ({ navigate, lang }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'latest' | 'popular'>('latest');

  const filtered = ARTICLES.filter((art) => {
    if (selectedCategory === 'all') return true;
    return art.categorySlug === selectedCategory;
  }).sort((a, b) => {
    if (sortOrder === 'latest') {
      return new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime();
    }
    return (b.isTrending ? 1 : 0) - (a.isTrending ? 1 : 0);
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'सभी ब्लॉग लेख' : 'Blog' }]} navigate={navigate} />

      <div className="mt-4 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
            {lang === 'hi' ? 'वित्तीय ज्ञान भंडार' : 'Financial Insights'}
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
            {lang === 'hi' ? 'ब्लॉग एवं विस्तृत गाइड्स' : 'All Articles & Guides'}
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
            {lang === 'hi'
              ? 'म्यूचुअल फंड, बैंकिंग, लोन और टैक्स पर विशेषज्ञों द्वारा लिखे गए प्रामाणिक आलेख।'
              : 'Actionable financial guides written by verified CFP and CA experts.'}
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 text-xs font-medium rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
          >
            <option value="all">{lang === 'hi' ? 'सभी श्रेणियां (All)' : 'All Categories'}</option>
            {CATEGORIES.map((cat) => (
              <option key={cat.id} value={cat.slug}>
                {lang === 'hi' ? cat.nameHi : cat.name}
              </option>
            ))}
          </select>

          <select
            value={sortOrder}
            onChange={(e) => setSortOrder(e.target.value as any)}
            className="px-3 py-2 text-xs font-medium rounded-lg bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
          >
            <option value="latest">{lang === 'hi' ? 'नवीनतम पहले' : 'Latest First'}</option>
            <option value="popular">{lang === 'hi' ? 'लोकप्रिय / ट्रेंडिंग' : 'Most Popular'}</option>
          </select>
        </div>
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((art) => (
          <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
        ))}
      </div>

      <AdContainer slotId="blog-feed-bottom" format="horizontal" className="mt-12" />
    </div>
  );
};
