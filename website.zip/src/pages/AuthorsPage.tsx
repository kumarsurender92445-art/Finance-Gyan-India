import React from 'react';
import { ArrowRight, ShieldCheck, Mail } from 'lucide-react';
import { AUTHORS } from '../data/authors';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Language } from '../types';

interface AuthorsPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const AuthorsPage: React.FC<AuthorsPageProps> = ({ navigate, lang }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'संपादकीय लेखक एवं विशेषज्ञ' : 'Authors' }]} navigate={navigate} />

      <div className="mt-4 mb-8 max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
          {lang === 'hi' ? 'विशेषज्ञ लेखक मंडल' : 'Editorial Board'}
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? 'हमारे प्रमाणित वित्तीय लेखक एवं सलाहकार' : 'Our Financial Experts & Authors'}
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
          {lang === 'hi'
            ? 'Finance Gyan India की प्रत्येक मार्गदर्शिका सर्टिफाइड फाइनेंशियल प्लानर्स (CFP®), चार्टर्ड अकाउंटेंट्स (CA) और दशकों का बाजार अनुभव रखने वाले विशेषज्ञों द्वारा लिखी और जांची जाती है।'
            : 'All guides are researched and authored by certified professionals holding CFP® and CA credentials.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {AUTHORS.map((author) => (
          <div
            key={author.id}
            onClick={() => navigate(`/author/${author.id}`)}
            className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:shadow-md cursor-pointer transition-all flex flex-col justify-between group"
          >
            <div>
              <img
                src={author.avatar}
                alt={author.name}
                className="w-20 h-20 rounded-full object-cover border border-slate-200 dark:border-slate-700 mb-4"
              />
              <h2 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                {lang === 'hi' ? author.nameHi : author.name}
              </h2>
              <p className="text-xs font-semibold text-teal-700 dark:text-teal-400 mt-0.5">
                {lang === 'hi' ? author.roleHi : author.role}
              </p>
              <p className="mt-3 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-3">
                {lang === 'hi' ? author.bioHi : author.bio}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/80 space-y-1">
                {author.credentials.map((cred, i) => (
                  <div key={i} className="text-[11px] text-slate-500 font-mono flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                    <span>{cred}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-teal-700 dark:text-teal-400">
              <span>{author.articleCount} {lang === 'hi' ? 'प्रकाशित लेख' : 'Articles'}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
