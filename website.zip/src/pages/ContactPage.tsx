import React, { useState } from 'react';
import { Mail, MapPin, Send, CheckCircle2, AlertTriangle, ShieldAlert } from 'lucide-react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Language } from '../types';

interface ContactPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const ContactPage: React.FC<ContactPageProps> = ({ navigate, lang }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'general',
    message: '',
    honeypot: '', // spam prevention bot trap
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Spam honeypot detection
    if (formData.honeypot) {
      return;
    }

    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setError(lang === 'hi' ? 'कृपया सभी अनिवार्य फ़ील्ड भरें।' : 'Please fill all required fields.');
      return;
    }

    if (!formData.email.includes('@') || !formData.email.includes('.')) {
      setError(lang === 'hi' ? 'कृपया वैध ईमेल आईडी दर्ज करें।' : 'Please enter a valid email address.');
      return;
    }

    // Security warning check: Ensure user hasn't typed sensitive financial numbers
    const sensitiveWords = ['otp', 'pin', 'cvv', 'password', 'पिन', 'पासवर्ड'];
    const hasSensitive = sensitiveWords.some((w) =>
      formData.message.toLowerCase().includes(w)
    );
    if (hasSensitive) {
      setError(
        lang === 'hi'
          ? 'सुरक्षा चेतावनी: कृपया कोई भी बैंक पिन, पासवर्ड या ओटीपी संदेश में न लिखें!'
          : 'Security Alert: Never share bank PINs, OTPs, or passwords!'
      );
      return;
    }

    setError('');
    setSubmitted(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'संपर्क करें' : 'Contact Us' }]} navigate={navigate} />

      <div className="mt-4 mb-10 max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
          {lang === 'hi' ? 'संपादकीय संपर्क' : 'Get in Touch'}
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? 'हमसे संपर्क करें (Contact Us)' : 'Contact Finance Gyan India'}
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-300">
          {lang === 'hi'
            ? 'संपादकीय सुधार, प्रतिक्रिया, विज्ञापन पूछताछ या लेख संबंधी सुझावों के लिए हमसे संपर्क करें।'
            : 'For editorial inquiries, fact-checking corrections, advertising, or general reader feedback.'}
        </p>
      </div>

      {/* Critical Security Warning Card */}
      <div className="mb-8 p-4 rounded-xl bg-rose-50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900 text-rose-900 dark:text-rose-200 flex items-start gap-3">
        <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
        <div className="text-xs sm:text-sm leading-relaxed">
          <span className="font-bold">सख्त सुरक्षा चेतावनी (Strict Security Notice): </span>
          Finance Gyan India कभी भी आपसे आपके बैंक खाते का पासवर्ड, नेट बैंकिंग लॉगिन, ATM पिन (PIN), कार्ड का CVV या मोबाइल OTP नहीं मांगता। संपर्क फॉर्म में केवल सामान्य प्रश्न ही लिखें। कभी भी अपनी निजी वित्तीय जानकारी साझा न करें।
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Contact Form */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-800/90 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm">
          {submitted ? (
            <div className="py-12 text-center space-y-4">
              <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-950 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                {lang === 'hi' ? 'आपका संदेश प्राप्त हो गया है!' : 'Message Received!'}
              </h2>
              <p className="text-sm text-slate-600 dark:text-slate-300 max-w-md mx-auto leading-relaxed">
                {lang === 'hi'
                  ? 'आपकी पूछताछ हमारे संपादकीय डेस्क को भेज दी गई है। हमारी टीम 24 से 48 व्यावसायिक घंटों में आपके ईमेल पर उत्तर देगी।'
                  : 'Thank you for reaching out. Our editorial team will review your inquiry within 24–48 business hours.'}
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setFormData({ name: '', email: '', subject: 'general', message: '', honeypot: '' });
                }}
                className="mt-4 px-4 py-2 text-xs font-semibold text-teal-700 bg-teal-50 dark:bg-teal-950 rounded-lg hover:bg-teal-100"
              >
                {lang === 'hi' ? 'एक और संदेश भेजें' : 'Send another message'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Invisible spam honeypot trap */}
              <input
                type="text"
                name="user_token_trap"
                value={formData.honeypot}
                onChange={(e) => setFormData({ ...formData, honeypot: e.target.value })}
                className="hidden"
                tabIndex={-1}
                autoComplete="off"
              />

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'hi' ? 'आपका नाम (Full Name) *' : 'Full Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g. Suresh Kumar"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'hi' ? 'ईमेल पता (Email Address) *' : 'Email Address *'}
                </label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  placeholder="name@example.com"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'hi' ? 'विषय (Subject Category)' : 'Subject Category'}
                </label>
                <select
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm text-slate-900 dark:text-white focus:outline-none"
                >
                  <option value="general">{lang === 'hi' ? 'सामान्य पाठक प्रतिक्रिया (General Feedback)' : 'General Feedback'}</option>
                  <option value="correction">{lang === 'hi' ? 'तथ्य या डेटा सुधार (Correction Request)' : 'Fact Correction Request'}</option>
                  <option value="editorial">{lang === 'hi' ? 'संपादकीय सुझाव (Editorial Suggestion)' : 'Editorial Suggestion'}</option>
                  <option value="advertisement">{lang === 'hi' ? 'विज्ञापन व प्रायोजन (Advertising & Sponsorship)' : 'Advertising / Sponsorship'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'hi' ? 'आपका संदेश (Message) *' : 'Message *'}
                </label>
                <textarea
                  rows={4}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder={lang === 'hi' ? 'अपना संदेश यहाँ लिखें...' : 'Type your message here...'}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-sm text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              {error && (
                <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 text-xs font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3 bg-teal-700 hover:bg-teal-800 text-white font-semibold text-sm rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>{lang === 'hi' ? 'संदेश भेजें' : 'Send Message'}</span>
              </button>
            </form>
          )}
        </div>

        {/* Contact Info Sidebar */}
        <div className="lg:col-span-5 space-y-6">
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {lang === 'hi' ? 'सीधा संपर्क विवरण' : 'Direct Editorial Contacts'}
            </h3>

            <div className="space-y-3 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-teal-600 mt-1 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">संपादकीय डेस्क (Editorial)</div>
                  <div className="text-teal-700 dark:text-teal-400">editor@financegyanindia.com</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-teal-600 mt-1 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">तथ्य सुधार (Fact Checking)</div>
                  <div className="text-teal-700 dark:text-teal-400">corrections@financegyanindia.com</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-teal-600 mt-1 shrink-0" />
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">मुख्यालय (Headquarters)</div>
                  <div>नई दिल्ली, भारत (New Delhi, India)</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
