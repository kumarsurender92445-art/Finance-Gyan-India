import React from 'react';
import { Clock } from 'lucide-react';
import { ARTICLES } from '../data/articles';
import { ArticleCard } from '../components/ArticleCard';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Language } from '../types';

interface LatestPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const LatestPage: React.FC<LatestPageProps> = ({ navigate, lang }) => {
  const latest = [...ARTICLES].sort(
    (a, b) => new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime()
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'नवीनतम लेख' : 'Latest Articles' }]} navigate={navigate} />

      <div className="mt-4 mb-8 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
          <Clock className="w-4 h-4" />
          <span>{lang === 'hi' ? 'ताज़ा अपडेट' : 'Fresh Updates'}</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? 'नवीनतम वित्तीय लेख (Latest)' : 'Latest Financial Articles'}
        </h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          {lang === 'hi'
            ? 'हाल ही में प्रकाशित किए गए नए वित्तीय नियम, टैक्स स्लैब और बचत के तरीके।'
            : 'Recently published finance guides and regulatory reviews.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {latest.map((art) => (
          <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
        ))}
      </div>
    </div>
  );
};
