import React, { useState, useMemo } from 'react';
import { Calculator, ArrowLeft, Info, Printer, RefreshCw, AlertCircle, Share2, Check } from 'lucide-react';
import { CalculatorConfig, Language } from '../types';
import { calculateCalculatorResult, formatINR } from '../utils/calculatorMath';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { AdContainer } from '../components/AdContainer';
import { CALCULATORS } from '../data/calculators';

interface CalculatorDetailPageProps {
  calculator: CalculatorConfig;
  navigate: (path: string) => void;
  lang: Language;
}

export const CalculatorDetailPage: React.FC<CalculatorDetailPageProps> = ({
  calculator,
  navigate,
  lang,
}) => {
  // Initialize state with default values
  const initialValues = useMemo(() => {
    const res: Record<string, number> = {};
    calculator.fields.forEach((f) => {
      res[f.id] = f.defaultValue;
    });
    return res;
  }, [calculator]);

  const [values, setValues] = useState<Record<string, number>>(initialValues);
  const [copied, setCopied] = useState(false);

  // Recalculate on any input change
  const result = useMemo(() => {
    return calculateCalculatorResult(calculator.id, values);
  }, [calculator.id, values]);

  const handleFieldChange = (id: string, val: number, min: number, max: number) => {
    // Clamp values gracefully
    const clamped = isNaN(val) ? min : Math.min(max, Math.max(min, val));
    setValues((prev) => ({ ...prev, [id]: clamped }));
  };

  const handleReset = () => {
    setValues(initialValues);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const breadcrumbs = [
    { label: lang === 'hi' ? 'कैलकुलेटर' : 'Calculators', path: '/calculators' },
    { label: lang === 'hi' ? calculator.nameHi : calculator.name }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={breadcrumbs} navigate={navigate} />

      {/* Header */}
      <div className="mt-2 mb-8 pb-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <button
            onClick={() => navigate('/calculators')}
            className="text-xs text-teal-700 dark:text-teal-400 font-semibold flex items-center gap-1 mb-2 hover:underline"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'सभी कैलकुलेटर पर लौटें' : 'Back to All Calculators'}</span>
          </button>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            {lang === 'hi' ? calculator.nameHi : calculator.name}
          </h1>
          <p className="mt-1 text-sm text-slate-600 dark:text-slate-300">
            {lang === 'hi' ? calculator.descriptionHi : calculator.description}
          </p>
        </div>

        <div className="flex items-center gap-2 no-print">
          <button
            onClick={handleReset}
            className="p-2 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-1.5"
            title="रीसेट करें"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'रीसेट' : 'Reset'}</span>
          </button>
          <button
            onClick={() => window.print()}
            className="p-2 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-1.5"
            title="प्रिंट करें"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'प्रिंट' : 'Print'}</span>
          </button>
          <button
            onClick={handleShare}
            className="p-2 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 transition-colors flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? 'कॉपी हुआ' : 'शेयर'}</span>
          </button>
        </div>
      </div>

      {/* Calculator Interactive Grid: Inputs Left (50%), Live Results Right (50%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Inputs Panel */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-800/90 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <h2 className="text-base font-bold text-slate-900 dark:text-white pb-3 border-b border-slate-100 dark:border-slate-700">
            {lang === 'hi' ? 'अपनी जानकारी दर्ज करें (Inputs)' : 'Enter Parameters'}
          </h2>

          <div className="space-y-6">
            {calculator.fields.map((field) => {
              const currentVal = values[field.id] ?? field.defaultValue;

              return (
                <div key={field.id} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <label htmlFor={field.id} className="font-semibold text-slate-800 dark:text-slate-200">
                      {lang === 'hi' ? field.labelHi : field.label}
                    </label>
                    <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-900 px-3 py-1 rounded-lg border border-slate-200 dark:border-slate-700">
                      <span className="text-xs font-semibold text-teal-700 dark:text-teal-400 font-mono">
                        {field.unit === '₹' ? '₹' : ''}
                      </span>
                      <input
                        type="number"
                        id={field.id}
                        value={currentVal}
                        min={field.min}
                        max={field.max}
                        step={field.step}
                        onChange={(e) =>
                          handleFieldChange(field.id, parseFloat(e.target.value), field.min, field.max)
                        }
                        className="w-24 sm:w-28 text-right bg-transparent text-sm font-bold font-mono text-slate-900 dark:text-white focus:outline-none"
                      />
                      {field.unit !== '₹' && (
                        <span className="text-xs text-slate-500 font-medium">{field.unit}</span>
                      )}
                    </div>
                  </div>

                  {/* Range Slider for immediate tactile manipulation */}
                  <input
                    type="range"
                    min={field.min}
                    max={field.max}
                    step={field.step}
                    value={currentVal}
                    onChange={(e) =>
                      handleFieldChange(field.id, parseFloat(e.target.value), field.min, field.max)
                    }
                    className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-teal-700"
                  />

                  <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                    <span>{field.unit === '₹' ? `₹${field.min.toLocaleString('en-IN')}` : `${field.min} ${field.unit}`}</span>
                    <span>{field.unit === '₹' ? `₹${field.max.toLocaleString('en-IN')}` : `${field.max} ${field.unit}`}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Output Panel */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md">
            <span className="text-xs font-semibold tracking-wider uppercase text-teal-400">
              {lang === 'hi' ? result.primaryLabelHi : result.primaryLabel}
            </span>

            {/* Huge Tabular Numerals Primary Output */}
            <div className="mt-2 text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-mono tabular-nums text-white">
              {formatINR(result.primaryValue)}
            </div>

            {/* Proportion Bar */}
            {result.breakdown && result.breakdown.length > 0 && (
              <div className="mt-6 space-y-2">
                <div className="h-3 w-full bg-slate-800 rounded-full overflow-hidden flex">
                  {result.breakdown.map((b, i) => (
                    <div
                      key={i}
                      style={{ width: `${Math.max(2, b.percentage)}%`, backgroundColor: b.color }}
                      className="h-full transition-all duration-300"
                    />
                  ))}
                </div>
                <div className="flex flex-wrap items-center justify-between text-xs text-slate-300 pt-1">
                  {result.breakdown.map((b, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: b.color }} />
                      <span>{lang === 'hi' ? b.labelHi : b.label}:</span>
                      <span className="font-mono font-bold text-white tabular-nums">
                        {formatINR(b.value)} ({Math.round(b.percentage)}%)
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Secondary Output Metrics */}
            {result.secondaryValues.length > 0 && (
              <div className="mt-6 pt-6 border-t border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
                {result.secondaryValues.map((sec, idx) => (
                  <div key={idx} className="bg-slate-800/60 p-3 rounded-lg border border-slate-700/60">
                    <div className="text-xs text-slate-400">
                      {lang === 'hi' ? sec.labelHi : sec.label}
                    </div>
                    <div className="text-lg font-bold font-mono tabular-nums text-white mt-0.5">
                      {sec.format === 'currency'
                        ? formatINR(sec.value)
                        : sec.format === 'percent'
                        ? `${sec.value.toFixed(1)}%`
                        : sec.format === 'years'
                        ? `${Math.round(sec.value)} वर्ष`
                        : sec.value.toFixed(1)}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Recommendation Callout */}
            {result.recommendationHi && (
              <div className="mt-5 p-3 rounded-lg bg-teal-950/60 border border-teal-800/80 text-xs text-teal-200 flex items-start gap-2">
                <Info className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <p className="leading-relaxed">{result.recommendationHi}</p>
              </div>
            )}
          </div>

          {/* Guaranteed Return Disclaimers Notice */}
          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-semibold">महत्वपूर्ण सूचना: </span>
              यह परिणाम केवल अनुमानित (Projections are estimates) और सांकेतिक हैं। यह किसी बैंक, ब्रोकर या वित्तीय संस्था द्वारा गारंटीकृत रिटर्न का वादा नहीं है। वास्तविक रिटर्न बाजार के जोखिम, लागू टैक्स नियमों और बैंक के ब्याज दर संशोधनों पर निर्भर करते हैं।
            </div>
          </div>
        </div>
      </div>

      {/* AdSense Unit */}
      <AdContainer slotId="calculator-result-leaderboard" format="horizontal" />

      {/* Formula & Mathematical Explanation */}
      <section className="mt-12 p-6 sm:p-8 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800 space-y-6">
        <div>
          <h3 className="text-lg font-bold text-slate-900 dark:text-white tracking-tight">
            {lang === 'hi' ? 'गणना का फॉर्मूला और गणितीय विधि' : 'Calculation Formula & Methodology'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {lang === 'hi' ? 'पारदर्शिता के साथ समझें कि यह कैलकुलेटर किस गणितीय समीकरण पर कार्य करता है।' : 'Transparent mathematical breakdown.'}
          </p>
        </div>

        {/* Math Formula Display */}
        <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 font-mono text-sm sm:text-base text-teal-800 dark:text-teal-300 border border-slate-200 dark:border-slate-700 text-center overflow-x-auto">
          {calculator.formulaExplanation.formula}
        </div>

        <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          {calculator.formulaExplanation.explanationHi}
        </p>

        {/* Variables Table */}
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-xs sm:text-sm">
            <thead className="bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-2.5 px-3">संकेत (Symbol)</th>
                <th className="py-2.5 px-3">विवरण (Parameter)</th>
                <th className="py-2.5 px-3">अर्थ (Explanation)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {calculator.formulaExplanation.variables.map((v, i) => (
                <tr key={i}>
                  <td className="py-2.5 px-3 font-mono font-bold text-teal-700 dark:text-teal-400">{v.symbol}</td>
                  <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">{v.nameHi}</td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{v.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Assumptions List */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-700">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-2">
            मान्यताएं एवं शर्तें (Assumptions):
          </h4>
          <ul className="space-y-1 text-xs text-slate-600 dark:text-slate-400">
            {calculator.assumptions.map((ass, i) => (
              <li key={i} className="flex items-start gap-1.5">
                <span className="font-bold text-teal-700">•</span>
                <span>{ass}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Other Recommended Calculators */}
      <section className="mt-12">
        <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight mb-6">
          {lang === 'hi' ? 'अन्य लोकप्रिय वित्तीय कैलकुलेटर' : 'Other Popular Calculators'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {CALCULATORS.filter((c) => c.id !== calculator.id).slice(0, 3).map((calc) => (
            <div
              key={calc.id}
              onClick={() => navigate(`/calculator/${calc.slug}`)}
              className="p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-800 hover:border-teal-500 cursor-pointer transition-all"
            >
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                {lang === 'hi' ? calc.nameHi : calc.name}
              </h4>
              <p className="mt-1 text-xs text-slate-500 line-clamp-2">
                {lang === 'hi' ? calc.descriptionHi : calc.description}
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
