import React from 'react';
import { ArrowRight, BookOpen } from 'lucide-react';
import { CATEGORIES } from '../data/categories';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Language } from '../types';

interface CategoriesPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const CategoriesPage: React.FC<CategoriesPageProps> = ({ navigate, lang }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'सभी श्रेणियां' : 'All Categories' }]} navigate={navigate} />

      <div className="mt-4 mb-8 max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
          {lang === 'hi' ? 'वित्तीय विषय' : 'Topic Directory'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? 'सभी वित्तीय श्रेणियां (Categories)' : 'All Financial Categories'}
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-300">
          {lang === 'hi'
            ? 'अपनी पसंद का विषय चुनें—चाहे वह पहली बार म्यूचुअल फंड में निवेश हो, इनकम टैक्स बचाना हो, या कर्ज से मुक्ति पाना हो।'
            : 'Explore categorized guides covering investing, loans, insurance, budgeting, and taxation.'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {CATEGORIES.map((cat) => (
          <div
            key={cat.id}
            onClick={() => navigate(`/category/${cat.slug}`)}
            className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 mb-3 text-teal-700 dark:text-teal-400 font-bold text-xs uppercase tracking-wider">
                <BookOpen className="w-4 h-4" />
                <span>{cat.articleCount} {lang === 'hi' ? 'मार्गदर्शिकाएं' : 'Articles'}</span>
              </div>

              <h2 className="text-lg font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                {lang === 'hi' ? cat.nameHi : cat.name}
              </h2>

              <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {lang === 'hi' ? cat.descriptionHi : cat.description}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-teal-700 dark:text-teal-400">
              <span>{lang === 'hi' ? 'लेख पढ़ें' : 'View Articles'}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
