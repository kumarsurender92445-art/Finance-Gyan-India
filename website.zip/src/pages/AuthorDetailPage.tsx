import React from 'react';
import { ArrowLeft, ShieldCheck, Mail } from 'lucide-react';
import { Author, Language } from '../types';
import { ARTICLES } from '../data/articles';
import { ArticleCard } from '../components/ArticleCard';
import { Breadcrumbs } from '../components/Breadcrumbs';

interface AuthorDetailPageProps {
  author: Author;
  navigate: (path: string) => void;
  lang: Language;
}

export const AuthorDetailPage: React.FC<AuthorDetailPageProps> = ({
  author,
  navigate,
  lang,
}) => {
  const authorArticles = ARTICLES.filter((a) => a.authorId === author.id);

  const breadcrumbs = [
    { label: lang === 'hi' ? 'लेखक मंडल' : 'Authors', path: '/authors' },
    { label: lang === 'hi' ? author.nameHi : author.name }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={breadcrumbs} navigate={navigate} />

      <div className="mt-4 mb-10 bg-white dark:bg-slate-800/90 rounded-2xl p-6 sm:p-10 border border-slate-200 dark:border-slate-800">
        <button
          onClick={() => navigate('/authors')}
          className="text-xs text-teal-700 dark:text-teal-400 font-semibold flex items-center gap-1 mb-6 hover:underline"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{lang === 'hi' ? 'सभी लेखकों पर लौटें' : 'Back to Authors'}</span>
        </button>

        <div className="flex flex-col md:flex-row gap-6 items-start">
          <img
            src={author.avatar}
            alt={author.name}
            className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover border-2 border-teal-600 shrink-0"
          />
          <div className="space-y-3">
            <div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
                {lang === 'hi' ? author.nameHi : author.name}
              </h1>
              <p className="text-sm font-semibold text-teal-700 dark:text-teal-400 mt-1">
                {lang === 'hi' ? author.roleHi : author.role}
              </p>
            </div>

            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-3xl">
              {lang === 'hi' ? author.bioHi : author.bio}
            </p>

            <div className="pt-2 flex flex-wrap gap-2">
              {author.credentials.map((cred, i) => (
                <div key={i} className="text-xs font-mono bg-slate-100 dark:bg-slate-700/80 px-2.5 py-1 rounded text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
                  <span>{cred}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Articles by Author */}
      <div>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white mb-6">
          {lang === 'hi' ? `${author.nameHi} द्वारा लिखे गए आलेख` : `Articles Written by ${author.name}`}
        </h2>

        {authorArticles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {authorArticles.map((art) => (
              <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
            ))}
          </div>
        ) : (
          <p className="text-sm text-slate-500">
            {lang === 'hi' ? 'इस लेखक के अन्य आलेख शीघ्र जोड़े जा रहे हैं।' : 'More articles from this author coming soon.'}
          </p>
        )}
      </div>
    </div>
  );
};
