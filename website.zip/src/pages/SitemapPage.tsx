import React from 'react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { CATEGORIES } from '../data/categories';
import { CALCULATORS } from '../data/calculators';
import { ARTICLES } from '../data/articles';
import { AUTHORS } from '../data/authors';
import { Language } from '../types';

interface SitemapPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const SitemapPage: React.FC<SitemapPageProps> = ({ navigate, lang }) => {
  const mainPages = [
    { label: 'होम पेज (Home)', path: '/' },
    { label: 'हमारे बारे में (About Us)', path: '/about' },
    { label: 'संपर्क करें (Contact Us)', path: '/contact' },
    { label: 'सभी ब्लॉग लेख (Blog)', path: '/blog' },
    { label: 'सभी श्रेणियां (All Categories)', path: '/categories' },
    { label: 'सर्च पेज (Search)', path: '/search' },
    { label: 'लेखक एवं विशेषज्ञ (Authors)', path: '/authors' },
    { label: 'ट्रेंडिंग लेख (Trending)', path: '/trending' },
    { label: 'नवीनतम लेख (Latest Articles)', path: '/latest' },
    { label: 'वित्तीय कैलकुलेटर केंद्र (Calculators Hub)', path: '/calculators' },
  ];

  const legalPages = [
    { label: 'गोपनीयता नीति (Privacy Policy)', path: '/privacy-policy' },
    { label: 'नियम और शर्तें (Terms & Conditions)', path: '/terms' },
    { label: 'सामान्य अस्वीकरण (Disclaimer)', path: '/disclaimer' },
    { label: 'वित्तीय अस्वीकरण (Financial Disclaimer)', path: '/financial-disclaimer' },
    { label: 'एफिलिएट प्रकटीकरण (Affiliate Disclosure)', path: '/affiliate-disclosure' },
    { label: 'संपादकीय नीति (Editorial Policy)', path: '/editorial-policy' },
    { label: 'त्रुटि सुधार नीति (Corrections Policy)', path: '/corrections' },
    { label: 'कुकी नीति (Cookie Policy)', path: '/cookie-policy' },
    { label: 'एचटीएमएल साइटमैप (Sitemap)', path: '/sitemap' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'साइटमैप' : 'HTML Sitemap' }]} navigate={navigate} />

      <div className="mt-4 mb-8 pb-4 border-b border-slate-200 dark:border-slate-800">
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          {lang === 'hi' ? 'वेबसाइट संपूर्ण साइटमैप (HTML Sitemap)' : 'HTML Sitemap'}
        </h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          {lang === 'hi'
            ? 'Finance Gyan India के सभी मुख्य पृष्ठों, 16 वित्तीय श्रेणियों, 12 कैलकुलेटरों और कानूनी दस्तावेजों की पूरी सूची।'
            : 'Complete directory of all pages, categories, calculators, and legal policies.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {/* Main Pages */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 pb-2 border-b border-slate-100 dark:border-slate-700">
            मुख्य पृष्ठ (Main Pages)
          </h2>
          <ul className="space-y-2 text-xs sm:text-sm">
            {mainPages.map((p) => (
              <li key={p.path}>
                <button
                  onClick={() => navigate(p.path)}
                  className="text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:underline text-left"
                >
                  {p.label}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* 16 Finance Categories */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 pb-2 border-b border-slate-100 dark:border-slate-700">
            16 वित्तीय श्रेणियां (Categories)
          </h2>
          <ul className="space-y-2 text-xs sm:text-sm">
            {CATEGORIES.map((cat) => (
              <li key={cat.id}>
                <button
                  onClick={() => navigate(`/category/${cat.slug}`)}
                  className="text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:underline text-left"
                >
                  {cat.nameHi} ({cat.name})
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* 12 Financial Calculators */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 pb-2 border-b border-slate-100 dark:border-slate-700">
            12 वित्तीय कैलकुलेटर (Live Calculators)
          </h2>
          <ul className="space-y-2 text-xs sm:text-sm">
            {CALCULATORS.map((calc) => (
              <li key={calc.id}>
                <button
                  onClick={() => navigate(`/calculator/${calc.slug}`)}
                  className="text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:underline text-left"
                >
                  {calc.nameHi}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Blog Guides */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 pb-2 border-b border-slate-100 dark:border-slate-700">
            विस्तृत आलेख (Articles)
          </h2>
          <ul className="space-y-2 text-xs sm:text-sm">
            {ARTICLES.map((art) => (
              <li key={art.id}>
                <button
                  onClick={() => navigate(`/article/${art.slug}`)}
                  className="text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:underline text-left line-clamp-1"
                >
                  {art.titleHi}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Authors */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 pb-2 border-b border-slate-100 dark:border-slate-700">
            विशेषज्ञ लेखक (Authors)
          </h2>
          <ul className="space-y-2 text-xs sm:text-sm">
            {AUTHORS.map((auth) => (
              <li key={auth.id}>
                <button
                  onClick={() => navigate(`/author/${auth.id}`)}
                  className="text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:underline text-left"
                >
                  {auth.nameHi} - {auth.credentials[0]}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Legal & Policies */}
        <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 pb-2 border-b border-slate-100 dark:border-slate-700">
            कानूनी व विश्वास नीतियां (Legal Pages)
          </h2>
          <ul className="space-y-2 text-xs sm:text-sm">
            {legalPages.map((leg) => (
              <li key={leg.path}>
                <button
                  onClick={() => navigate(leg.path)}
                  className="text-slate-700 dark:text-slate-300 hover:text-teal-700 dark:hover:text-teal-400 hover:underline text-left"
                >
                  {leg.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
