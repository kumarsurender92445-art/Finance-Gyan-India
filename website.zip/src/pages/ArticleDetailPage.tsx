import React, { useState } from 'react';
import { Clock, Calendar, Share2, Check, ExternalLink, ChevronDown, ChevronUp, AlertCircle, BookOpen, ShieldCheck } from 'lucide-react';
import { Article, Language } from '../types';
import { CATEGORIES } from '../data/categories';
import { AUTHORS } from '../data/authors';
import { ARTICLES } from '../data/articles';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { AdContainer } from '../components/AdContainer';
import { ArticleCard } from '../components/ArticleCard';

interface ArticleDetailPageProps {
  article: Article;
  navigate: (path: string) => void;
  lang: Language;
}

export const ArticleDetailPage: React.FC<ArticleDetailPageProps> = ({
  article,
  navigate,
  lang,
}) => {
  const [copied, setCopied] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const category = CATEGORIES.find((c) => c.slug === article.categorySlug);
  const author = AUTHORS.find((a) => a.id === article.authorId);
  const relatedArticles = ARTICLES.filter((a) => a.id !== article.id && a.categorySlug === article.categorySlug).concat(
    ARTICLES.filter((a) => a.id !== article.id && a.categorySlug !== article.categorySlug)
  ).slice(0, 3);

  const shareUrl = typeof window !== 'undefined' ? window.location.href : `https://financegyanindia.com/article/${article.slug}`;
  const shareTitle = lang === 'hi' ? article.titleHi : article.title;

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const breadcrumbs = [
    { label: lang === 'hi' ? 'ब्लॉग' : 'Blog', path: '/blog' },
    { label: category ? (lang === 'hi' ? category.nameHi : category.name) : 'Finance', path: category ? `/category/${category.slug}` : undefined },
    { label: lang === 'hi' ? article.titleHi : article.title }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Breadcrumb Navigation */}
      <Breadcrumbs items={breadcrumbs} navigate={navigate} />

      {/* Main Grid: Article Content (70%) + Sidebar (30%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mt-4">
        {/* Main Article Column */}
        <article className="lg:col-span-8">
          {/* Article Header */}
          <header className="space-y-4 pb-6 border-b border-slate-200 dark:border-slate-800">
            {/* Zero-Pill Unboxed Metadata */}
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <button
                onClick={() => category && navigate(`/category/${category.slug}`)}
                className="font-bold text-teal-700 dark:text-teal-400 uppercase tracking-wider hover:underline"
              >
                {category ? (lang === 'hi' ? category.nameHi : category.name) : 'Finance'}
              </button>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" />
                {lang === 'hi' ? `प्रकाशित: ${article.publishedDate}` : `Published: ${article.publishedDate}`}
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {article.readTimeMinutes} min read
              </span>
              {article.updatedDate && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                    {lang === 'hi' ? `अपडेट: ${article.updatedDate}` : `Updated: ${article.updatedDate}`}
                  </span>
                </>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-[1.2]">
              {lang === 'hi' ? article.titleHi : article.title}
            </h1>

            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed font-normal">
              {lang === 'hi' ? article.excerptHi : article.excerpt}
            </p>

            {/* Author Credit Bar & Social Sharing */}
            <div className="pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              {author && (
                <div
                  onClick={() => navigate(`/author/${author.id}`)}
                  className="flex items-center gap-3 cursor-pointer group"
                >
                  <img
                    src={author.avatar}
                    alt={author.name}
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
                  />
                  <div>
                    <div className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                      {lang === 'hi' ? author.nameHi : author.name}
                    </div>
                    <div className="text-xs text-slate-500">
                      {lang === 'hi' ? author.roleHi : author.role}
                    </div>
                  </div>
                </div>
              )}

              {/* Social Share Buttons */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-medium mr-1">
                  {lang === 'hi' ? 'शेयर करें:' : 'Share:'}
                </span>
                <a
                  href={`https://api.whatsapp.com/send?text=${encodeURIComponent(shareTitle + ' - ' + shareUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1 text-xs font-medium text-emerald-800 bg-emerald-100 rounded hover:bg-emerald-200 transition-colors"
                >
                  WhatsApp
                </a>
                <a
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodeURIComponent(shareUrl)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1 text-xs font-medium text-slate-800 bg-slate-100 dark:bg-slate-800 dark:text-slate-200 rounded hover:bg-slate-200 transition-colors"
                >
                  X (Twitter)
                </a>
                <button
                  onClick={handleCopyLink}
                  className="px-2.5 py-1 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded hover:bg-slate-200 transition-colors flex items-center gap-1"
                >
                  {copied ? <Check className="w-3 h-3 text-emerald-600" /> : <Share2 className="w-3 h-3" />}
                  <span>{copied ? 'कॉपी हुआ!' : 'लिंक'}</span>
                </button>
              </div>
            </div>
          </header>

          {/* Featured Image */}
          <div className="my-6 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 aspect-video bg-slate-100 dark:bg-slate-800">
            <img
              src={article.featuredImage}
              alt={article.featuredImageAlt}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Ad Container after introduction / hero */}
          <AdContainer slotId="article-top-leaderboard" format="horizontal" />

          {/* Table of Contents (TOC) */}
          <div className="my-6 p-5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white mb-3">
              <BookOpen className="w-4 h-4 text-teal-700 dark:text-teal-400" />
              <span>{lang === 'hi' ? 'विषय-सूची (Table of Contents)' : 'Table of Contents'}</span>
            </div>
            <ul className="space-y-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
              {article.content.sections.map((section, idx) => (
                <li key={section.id}>
                  <a
                    href={`#${section.id}`}
                    className="hover:text-teal-700 dark:hover:text-teal-400 hover:underline flex items-center gap-2"
                  >
                    <span className="text-teal-700 dark:text-teal-400 font-mono text-xs">{idx + 1}.</span>
                    <span>{section.title}</span>
                  </a>
                </li>
              ))}
              <li>
                <a href="#frequently-asked-questions" className="hover:text-teal-700 dark:hover:text-teal-400 hover:underline flex items-center gap-2">
                  <span className="text-teal-700 dark:text-teal-400 font-mono text-xs">{article.content.sections.length + 1}.</span>
                  <span>{lang === 'hi' ? 'अक्सर पूछे जाने वाले सवाल (FAQs)' : 'Frequently Asked Questions'}</span>
                </a>
              </li>
              <li>
                <a href="#official-sources" className="hover:text-teal-700 dark:hover:text-teal-400 hover:underline flex items-center gap-2">
                  <span className="text-teal-700 dark:text-teal-400 font-mono text-xs">{article.content.sections.length + 2}.</span>
                  <span>{lang === 'hi' ? 'आधिकारिक स्रोत एवं संदर्भ' : 'Official Sources'}</span>
                </a>
              </li>
            </ul>
          </div>

          {/* Article Introduction */}
          <div className="prose prose-slate dark:prose-invert max-w-none text-base text-slate-700 dark:text-slate-300 leading-relaxed space-y-4">
            <p className="first-letter:text-4xl first-letter:font-bold first-letter:text-teal-800 dark:first-letter:text-teal-400 first-letter:mr-2">
              {article.content.introduction}
            </p>
          </div>

          {/* Article Main Sections */}
          <div className="mt-8 space-y-10">
            {article.content.sections.map((sec, index) => (
              <section key={sec.id} id={sec.id} className="scroll-mt-20 space-y-4">
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
                  {sec.title}
                </h2>

                <div className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line">
                  {sec.content}
                </div>

                {/* Callout Box */}
                {sec.callout && (
                  <div className="p-4 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-teal-950 dark:text-teal-200 my-4">
                    <div className="font-semibold text-sm flex items-center gap-2 mb-1">
                      <AlertCircle className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                      <span>{sec.callout.title}</span>
                    </div>
                    <p className="text-xs sm:text-sm leading-relaxed">{sec.callout.text}</p>
                  </div>
                )}

                {/* Data Table */}
                {sec.table && (
                  <div className="overflow-x-auto my-4 rounded-xl border border-slate-200 dark:border-slate-800">
                    <table className="min-w-full divide-y divide-slate-200 dark:divide-slate-800 text-left text-xs sm:text-sm">
                      <thead className="bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold">
                        <tr>
                          {sec.table.headers.map((h, i) => (
                            <th key={i} className="px-4 py-3">{h}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white dark:bg-slate-900">
                        {sec.table.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                            {row.map((cell, cIdx) => (
                              <td key={cIdx} className="px-4 py-3 text-slate-700 dark:text-slate-300 font-mono tabular-nums">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Pros and Cons */}
                {sec.prosAndCons && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-4">
                    <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                      <h4 className="text-sm font-bold text-emerald-900 dark:text-emerald-300 mb-2">
                        {lang === 'hi' ? '✓ प्रमुख फायदे' : 'Key Advantages'}
                      </h4>
                      <ul className="space-y-1.5 text-xs sm:text-sm text-emerald-950 dark:text-emerald-200">
                        {sec.prosAndCons.pros.map((p, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="font-bold text-emerald-700">•</span>
                            <span>{p}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800">
                      <h4 className="text-sm font-bold text-rose-900 dark:text-rose-300 mb-2">
                        {lang === 'hi' ? '✕ सावधानियां व कमियां' : 'Points to Consider'}
                      </h4>
                      <ul className="space-y-1.5 text-xs sm:text-sm text-rose-950 dark:text-rose-200">
                        {sec.prosAndCons.cons.map((c, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="font-bold text-rose-700">•</span>
                            <span>{c}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}

                {/* In-article Ad Placement between sections */}
                {index === 1 && <AdContainer slotId="article-mid-content" format="horizontal" />}
              </section>
            ))}
          </div>

          {/* FAQs Accordion */}
          <section id="frequently-asked-questions" className="mt-12 pt-8 border-t border-slate-200 dark:border-slate-800 scroll-mt-20">
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight mb-4">
              {lang === 'hi' ? 'अक्सर पूछे जाने वाले सवाल (FAQs)' : 'Frequently Asked Questions'}
            </h2>
            <div className="space-y-3">
              {article.content.faqs.map((faq, i) => (
                <div
                  key={i}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-white dark:bg-slate-900"
                >
                  <button
                    onClick={() => setOpenFaq(openFaq === i ? null : i)}
                    className="w-full px-5 py-3.5 text-left flex items-center justify-between text-sm sm:text-base font-semibold text-slate-900 dark:text-white hover:text-teal-700 transition-colors"
                  >
                    <span>{faq.question}</span>
                    {openFaq === i ? <ChevronUp className="w-4 h-4 shrink-0 text-slate-400" /> : <ChevronDown className="w-4 h-4 shrink-0 text-slate-400" />}
                  </button>
                  {openFaq === i && (
                    <div className="px-5 pb-4 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* Official Sources & References */}
          <section id="official-sources" className="mt-8 p-5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 scroll-mt-20">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-3">
              <ShieldCheck className="w-4 h-4 text-teal-700" />
              <span>{lang === 'hi' ? 'आधिकारिक सरकारी एवं विनियामक स्रोत' : 'Official Regulatory Sources & References'}</span>
            </h3>
            <ul className="space-y-2 text-xs sm:text-sm">
              {article.content.officialSources.map((source, i) => (
                <li key={i}>
                  <a
                    href={source.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1.5"
                  >
                    <span className="font-semibold text-slate-800 dark:text-slate-200">[{source.authority}]</span>
                    <span>{source.title}</span>
                    <ExternalLink className="w-3 h-3 text-slate-400" />
                  </a>
                </li>
              ))}
            </ul>
          </section>

          {/* Article Specific Disclaimer */}
          <div className="mt-6 p-4 rounded-lg bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 text-xs text-amber-900 dark:text-amber-200 leading-relaxed">
            <span className="font-semibold">{lang === 'hi' ? 'सलाह अस्वीकरण:' : 'Disclaimer:'} </span>
            {article.content.disclaimer}
          </div>

          {/* Author Full Biography Card */}
          {author && (
            <div className="mt-8 p-6 rounded-xl bg-white dark:bg-slate-800/80 border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-5 items-start">
              <img
                src={author.avatar}
                alt={author.name}
                className="w-16 h-16 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700"
              />
              <div className="space-y-2">
                <div>
                  <h4 className="text-base font-bold text-slate-900 dark:text-white">
                    {lang === 'hi' ? author.nameHi : author.name}
                  </h4>
                  <p className="text-xs text-teal-700 dark:text-teal-400 font-medium">
                    {lang === 'hi' ? author.roleHi : author.role}
                  </p>
                </div>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {lang === 'hi' ? author.bioHi : author.bio}
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  {author.credentials.map((cred, i) => (
                    <span key={i} className="text-[11px] font-mono text-slate-500 bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded">
                      {cred}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Related Articles */}
          <div className="mt-12 pt-8 border-t border-slate-200 dark:border-slate-800">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight mb-6">
              {lang === 'hi' ? 'संबंधित वित्तीय आलेख' : 'Related Financial Guides'}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {relatedArticles.map((rel) => (
                <ArticleCard key={rel.id} article={rel} navigate={navigate} lang={lang} layout="standard" />
              ))}
            </div>
          </div>
        </article>

        {/* Sidebar (30%) */}
        <aside className="lg:col-span-4 space-y-6">
          {/* Calculators Quick Jump */}
          <div className="bg-white dark:bg-slate-800/80 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              {lang === 'hi' ? 'त्वरित वित्तीय कैलकुलेटर' : 'Recommended Calculators'}
            </h4>
            <div className="space-y-2 text-xs">
              <button
                onClick={() => navigate('/calculator/sip-calculator')}
                className="w-full text-left p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 hover:bg-teal-50 dark:hover:bg-teal-950 font-medium text-slate-800 dark:text-slate-200 transition-colors flex items-center justify-between"
              >
                <span>SIP रिटर्न कैलकुलेटर</span>
                <span className="text-teal-700">→</span>
              </button>
              <button
                onClick={() => navigate('/calculator/loan-emi-calculator')}
                className="w-full text-left p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 hover:bg-teal-50 dark:hover:bg-teal-950 font-medium text-slate-800 dark:text-slate-200 transition-colors flex items-center justify-between"
              >
                <span>लोन EMI कैलकुलेटर</span>
                <span className="text-teal-700">→</span>
              </button>
              <button
                onClick={() => navigate('/calculator/income-tax-estimator')}
                className="w-full text-left p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900 hover:bg-teal-50 dark:hover:bg-teal-950 font-medium text-slate-800 dark:text-slate-200 transition-colors flex items-center justify-between"
              >
                <span>न्यू vs ओल्ड टैक्स एस्टिमेटर</span>
                <span className="text-teal-700">→</span>
              </button>
            </div>
          </div>

          {/* Sidebar Ad Placement */}
          <AdContainer slotId="article-sidebar-square" format="rectangle" />

          {/* Popular in this category */}
          <div className="bg-white dark:bg-slate-800/80 p-5 rounded-xl border border-slate-200 dark:border-slate-800">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
              {lang === 'hi' ? 'इस श्रेणी में लोकप्रिय' : 'More in this Category'}
            </h4>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {ARTICLES.slice(0, 3).map((art) => (
                <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="compact" />
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};
