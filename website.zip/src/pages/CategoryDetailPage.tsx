import React from 'react';
import { ArrowLeft, BookOpen } from 'lucide-react';
import { Category, Language } from '../types';
import { ARTICLES } from '../data/articles';
import { ArticleCard } from '../components/ArticleCard';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { AdContainer } from '../components/AdContainer';

interface CategoryDetailPageProps {
  category: Category;
  navigate: (path: string) => void;
  lang: Language;
}

export const CategoryDetailPage: React.FC<CategoryDetailPageProps> = ({
  category,
  navigate,
  lang,
}) => {
  const categoryArticles = ARTICLES.filter((a) => a.categorySlug === category.slug);
  // If few articles exist under this exact slug, offer additional popular articles
  const otherArticles = ARTICLES.filter((a) => a.categorySlug !== category.slug).slice(0, 3);

  const breadcrumbs = [
    { label: lang === 'hi' ? 'श्रेणियां' : 'Categories', path: '/categories' },
    { label: lang === 'hi' ? category.nameHi : category.name }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={breadcrumbs} navigate={navigate} />

      {/* Category Header */}
      <div className="mt-4 mb-8 pb-6 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => navigate('/categories')}
          className="text-xs text-teal-700 dark:text-teal-400 font-semibold flex items-center gap-1 mb-2 hover:underline"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{lang === 'hi' ? 'सभी श्रेणियों पर जाएं' : 'Back to Categories'}</span>
        </button>

        <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
          <BookOpen className="w-4 h-4" />
          <span>{categoryArticles.length} {lang === 'hi' ? 'विशेष लेख' : 'Featured Guides'}</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? category.nameHi : category.name}
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-300 max-w-3xl leading-relaxed">
          {lang === 'hi' ? category.descriptionHi : category.description}
        </p>
      </div>

      {/* Articles Grid */}
      {categoryArticles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categoryArticles.map((art) => (
            <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
          ))}
        </div>
      ) : (
        <div className="p-8 text-center bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
          <p className="text-slate-600 dark:text-slate-300 text-sm">
            {lang === 'hi'
              ? 'इस श्रेणी में नए संपादकीय लेख जल्द ही प्रकाशित किए जा रहे हैं।'
              : 'New editorial articles in this category will be published shortly.'}
          </p>
        </div>
      )}

      {/* AdSense Unit */}
      <AdContainer slotId="category-archive-slot" format="horizontal" className="mt-12" />

      {/* Other Related Categories Section */}
      <div className="mt-12 pt-8 border-t border-slate-200 dark:border-slate-800">
        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-6">
          {lang === 'hi' ? 'अन्य लोकप्रिय वित्तीय लेख' : 'You May Also Like'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {otherArticles.map((art) => (
            <ArticleCard key={art.id} article={art} navigate={navigate} lang={lang} layout="standard" />
          ))}
        </div>
      </div>
    </div>
  );
};
