import React, { useState } from 'react';
import { Calculator, ArrowRight, TrendingUp, Landmark, PieChart, Building2, ReceiptText } from 'lucide-react';
import { CALCULATORS } from '../data/calculators';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { AdContainer } from '../components/AdContainer';
import { Language } from '../types';

interface CalculatorsPageProps {
  navigate: (path: string) => void;
  lang: Language;
}

export const CalculatorsPage: React.FC<CalculatorsPageProps> = ({ navigate, lang }) => {
  const [filter, setFilter] = useState<'all' | 'investment' | 'loans' | 'planning' | 'banking' | 'tax'>('all');

  const filteredCalculators = filter === 'all'
    ? CALCULATORS
    : CALCULATORS.filter((c) => c.category === filter);

  const tabs = [
    { id: 'all', label: lang === 'hi' ? 'सभी (All 12)' : 'All 12 Tools' },
    { id: 'investment', label: lang === 'hi' ? 'निवेश एवं SIP' : 'Investment & SIP' },
    { id: 'loans', label: lang === 'hi' ? 'लोन एवं EMI' : 'Loans & EMI' },
    { id: 'planning', label: lang === 'hi' ? 'बजट एवं रिटायरमेंट' : 'Planning & Budget' },
    { id: 'banking', label: lang === 'hi' ? 'बैंकिंग (FD/RD)' : 'Banking' },
    { id: 'tax', label: lang === 'hi' ? 'इनकम टैक्स' : 'Income Tax' },
  ];

  const getCategoryIcon = (cat: string) => {
    switch (cat) {
      case 'investment': return <TrendingUp className="w-4 h-4 text-emerald-600" />;
      case 'loans': return <Landmark className="w-4 h-4 text-blue-600" />;
      case 'planning': return <PieChart className="w-4 h-4 text-purple-600" />;
      case 'banking': return <Building2 className="w-4 h-4 text-teal-600" />;
      case 'tax': return <ReceiptText className="w-4 h-4 text-rose-600" />;
      default: return <Calculator className="w-4 h-4 text-teal-600" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <Breadcrumbs items={[{ label: lang === 'hi' ? 'वित्तीय कैलकुलेटर' : 'Calculators' }]} navigate={navigate} />

      {/* Hero Header */}
      <div className="mt-4 mb-8 max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-700 dark:text-teal-400">
          {lang === 'hi' ? 'मुफ्त लाइव वित्तीय टूल्स' : 'Free Interactive Financial Tools'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {lang === 'hi' ? 'वित्तीय कैलकुलेटर केंद्र (Financial Calculators)' : 'Financial Calculators Hub'}
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
          {lang === 'hi'
            ? 'अपनी बचत, लोन ईएमआई, म्यूचुअल फंड SIP रिटर्न, रिटायरमेंट फंड और नए बनाम पुराने टैक्स रिजीम का सटीक हिसाब लगाएं। सभी टूल्स भारतीय नियमों और भारतीय रुपये (₹) के अनुरूप हैं।'
            : 'Plan your SIP investments, loan amortizations, FD maturity, and calculate taxes with clear Indian Rupee math.'}
        </p>
      </div>

      {/* Interactive Filter Tabs (Button Segmented Controls compliant with frontend-design) */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-200/70 dark:bg-slate-800 rounded-xl overflow-x-auto mb-8">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilter(tab.id as any)}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
              filter === tab.id
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Calculator Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCalculators.map((calc) => (
          <div
            key={calc.id}
            onClick={() => navigate(`/calculator/${calc.slug}`)}
            className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-800 hover:border-teal-500 hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950 flex items-center justify-center">
                  {getCategoryIcon(calc.category)}
                </div>
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                  {calc.category}
                </span>
              </div>

              <h2 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                {lang === 'hi' ? calc.nameHi : calc.name}
              </h2>

              <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
                {lang === 'hi' ? calc.descriptionHi : calc.description}
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between text-xs font-semibold text-teal-700 dark:text-teal-400">
              <span>{lang === 'hi' ? 'मुफ्त गणना शुरू करें' : 'Calculate Now'}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      {/* AdSense Unit */}
      <AdContainer slotId="calculators-hub-footer" format="horizontal" className="mt-12" />
    </div>
  );
};
