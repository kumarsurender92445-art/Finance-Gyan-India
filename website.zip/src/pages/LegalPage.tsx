import React from 'react';
import { ShieldCheck, FileText, AlertCircle, Scale, Lock, RefreshCw, CheckCircle2 } from 'lucide-react';
import { Breadcrumbs } from '../components/Breadcrumbs';
import { Language } from '../types';

export type LegalDocType =
  | 'privacy-policy'
  | 'terms'
  | 'disclaimer'
  | 'financial-disclaimer'
  | 'affiliate-disclosure'
  | 'editorial-policy'
  | 'corrections'
  | 'cookie-policy';

interface LegalPageProps {
  type: LegalDocType;
  navigate: (path: string) => void;
  lang: Language;
}

export const LegalPage: React.FC<LegalPageProps> = ({ type, navigate, lang }) => {
  const getDocDetails = () => {
    switch (type) {
      case 'privacy-policy':
        return {
          title: lang === 'hi' ? 'गोपनीयता नीति (Privacy Policy)' : 'Privacy Policy',
          updated: '1 अप्रैल 2026',
          content: (
            <div className="space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              <p>
                <strong>Finance Gyan India</strong> ("हम", "हमारी") में हम अपने पाठकों की गोपनीयता का सर्वोच्च सम्मान करते हैं। यह गोपनीयता नीति स्पष्ट करती है कि जब आप हमारी वेबसाइट पर आते हैं, तो हम किस प्रकार की जानकारी एकत्र करते हैं और उसका उपयोग कैसे किया जाता है।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">1. हम क्या जानकारी एकत्र करते हैं</h3>
              <p>
                • <strong>स्वैच्छिक जानकारी:</strong> जब आप हमारे न्यूज़लेटर की सदस्यता लेते हैं या संपर्क फॉर्म भरते हैं, तो हम केवल आपका नाम और ईमेल पता एकत्र करते हैं।
              </p>
              <p>
                • <strong>हम कभी भी संवेदनशील वित्तीय डेटा एकत्र नहीं करते:</strong> हम किसी भी उपयोगकर्ता से उनके बैंक खाते के नंबर, ATM पिन, पासवर्ड, डेबिट/क्रेडिट कार्ड CVV या OTP की मांग नहीं करते। हमारे सभी कैलकुलेटर क्लाइंट-साइड (ब्राउज़र) पर चलते हैं और आपका दर्ज किया गया डेटा हमारे सर्वर पर स्टोर नहीं होता।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">2. कुकीज़ एवं Google AdSense</h3>
              <p>
                हम वेबसाइट के प्रदर्शन और आगंतुकों के अनुभव को बेहतर बनाने के लिए मानक कुकीज़ का उपयोग करते हैं। Google AdSense और तीसरे पक्ष के विज्ञापनदाता प्रासंगिक विज्ञापन दिखाने के लिए कुकीज़ (जैसे DoubleClick DART कुकी) का उपयोग कर सकते हैं। आप अपनी ब्राउज़र सेटिंग्स में जाकर कुकीज़ को किसी भी समय अक्षम (Disable) कर सकते हैं।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">3. डेटा सुरक्षा</h3>
              <p>
                हम आपके डेटा को एन्क्रिप्टेड SSL/TLS प्रोटोकॉल के तहत सुरक्षित रखते हैं और इसे कभी भी तीसरे पक्षों को विपणन उद्देश्यों के लिए बेचते या किराए पर नहीं देते।
              </p>
            </div>
          )
        };

      case 'terms':
        return {
          title: lang === 'hi' ? 'नियम और शर्तें (Terms & Conditions)' : 'Terms & Conditions',
          updated: '1 अप्रैल 2026',
          content: (
            <div className="space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              <p>
                Finance Gyan India वेबसाइट का उपयोग करके आप निम्नलिखित नियमों और शर्तों से बंधे होने की सहमति देते हैं:
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">1. शैक्षिक सामग्री की प्रकृति</h3>
              <p>
                इस वेबसाइट पर उपलब्ध सभी आलेख, तुलना तालिकाएं और वित्तीय कैलकुलेटर केवल सामान्य वित्तीय साक्षरता और सूचनात्मक मार्गदर्शन के लिए हैं। इन्हें कानूनी, कर (Tax), या निवेश सलाहकार राय नहीं माना जाना चाहिए।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">2. बौद्धिक संपदा अधिकार</h3>
              <p>
                वेबसाइट का सारा टेक्स्ट, लोगो, कैलकुलेटर एल्गोरिदम और मूल ग्राफिक्स Finance Gyan India की बौद्धिक संपदा हैं। हमारी पूर्व लिखित अनुमति के बिना इन्हें व्यावसायिक उपयोग हेतु कॉपी करना निषिद्ध है।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">3. बाहरी वेबसाइटों के लिंक</h3>
              <p>
                हमारी वेबसाइट पर RBI, SEBI, आयकर विभाग या अन्य बाहरी संस्थाओं के लिंक संदर्भ हेतु दिए गए हैं। बाहरी वेबसाइटों की सामग्री या उनकी नीतियों के लिए हम उत्तरदायी नहीं हैं।
              </p>
            </div>
          )
        };

      case 'financial-disclaimer':
      case 'disclaimer':
        return {
          title: lang === 'hi' ? 'वित्तीय एवं कानूनी अस्वीकरण (Financial Disclaimer)' : 'Financial Disclaimer',
          updated: '1 अप्रैल 2026',
          content: (
            <div className="space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-900 text-amber-950 dark:text-amber-200">
                <strong>वैधानिक सूचना:</strong> Finance Gyan India भारतीय प्रतिभूति एवं विनिमय बोर्ड (SEBI) के तहत पंजीकृत निवेश सलाहकार (RIA) अथवा रिसर्च एनालिस्ट नहीं है।
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">1. कोई गारंटीकृत रिटर्न नहीं</h3>
              <p>
                म्यूचुअल फंड, शेयर बाजार, डिबेंचर और अन्य वित्तीय उपकरण बाजार जोखिमों के अधीन हैं। किसी भी फंड या इंडेक्स का पिछला प्रदर्शन भविष्य के रिटर्न की गारंटी नहीं है।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">2. कैलकुलेटर अनुमान</h3>
              <p>
                वेबसाइट पर दिए गए SIP कैलकुलेटर, लोन EMI कैलकुलेटर और रिटायरमेंट टूल्स के परिणाम केवल गणितीय अनुमान (Projections are estimates) हैं। वास्तविक रिटर्न बैंक ब्याज दरों में बदलाव, बाजार उतार-चढ़ाव और लागू टैक्स नियमों के अनुसार भिन्न हो सकते हैं।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">3. स्वतंत्र परामर्श आवश्यक</h3>
              <p>
                कोई भी बड़ा वित्तीय निर्णय, होम लोन या निवेश शुरू करने से पहले अपने सेबी-रजिस्टर्ड वित्तीय सलाहकार (CFP / RIA) अथवा चार्टर्ड अकाउंटेंट से अपनी वित्तीय स्थिति के अनुसार परामर्श अवश्य लें।
              </p>
            </div>
          )
        };

      case 'affiliate-disclosure':
        return {
          title: lang === 'hi' ? 'एफिलिएट प्रकटीकरण (Affiliate Disclosure)' : 'Affiliate Disclosure',
          updated: '1 अप्रैल 2026',
          content: (
            <div className="space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              <p>
                पारदर्शिता हमारे मूल्यों का मूल आधार है। हम अपने पाठकों को स्पष्ट रूप से सूचित करना चाहते हैं कि हमारी वेबसाइट पर कुछ अनुशंसित वित्तीय सेवाओं (जैसे डीमैट खाता खोलना, पुस्तकें, क्रेडिट कार्ड) के एफिलिएट लिंक हो सकते हैं।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">1. पाठक के लिए शून्य अतिरिक्त लागत</h3>
              <p>
                यदि आप किसी एफिलिएट लिंक पर क्लिक करके सेवा चुनते हैं, तो आपको इसके लिए एक भी अतिरिक्त रुपया नहीं देना पड़ता। बल्कि कई बार हमारे पाठकों को विशेष छूट या ऑफर का लाभ मिलता है।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">2. निष्पक्ष संपादकीय मानक</h3>
              <p>
                हम कभी भी केवल कमीशन कमाने के लिए किसी घटिया वित्तीय उत्पाद या उच्च जोखिम वाली योजना का प्रचार नहीं करते। हमारे संपादकीय लेख और समीक्षाएं स्वतंत्र हैं।
              </p>
            </div>
          )
        };

      case 'editorial-policy':
        return {
          title: lang === 'hi' ? 'संपादकीय नीति (Editorial Policy)' : 'Editorial Policy',
          updated: '1 अप्रैल 2026',
          content: (
            <div className="space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              <p>
                Finance Gyan India में हमारा लक्ष्य भारतीय पाठकों को सटीक, निष्पक्ष, और आसानी से समझ आने वाली वित्तीय जानकारी उपलब्ध कराना है।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">1. तथ्य-सत्यापन (Fact-Checking)</h3>
              <p>
                प्रत्येक लेख में उल्लिखित टैक्स स्लैब, ब्याज दरें और विनियामक नियम केवल आधिकारिक सरकारी स्रोतों (RBI, SEBI, CBDT, AMFI, EPFO) के परिपत्रों से क्रॉस-वेरिफाई किए जाते हैं।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">2. विशेषज्ञ समीक्षा</h3>
              <p>
                हमारे सभी आलेख प्रकाशित होने से पहले सर्टिफाइड फाइनेंशियल प्लानर (CFP) अथवा चार्टर्ड अकाउंटेंट (CA) द्वारा समीक्षित किए जाते हैं।
              </p>
            </div>
          )
        };

      case 'corrections':
        return {
          title: lang === 'hi' ? 'त्रुटि सुधार नीति (Corrections Policy)' : 'Corrections Policy',
          updated: '1 अप्रैल 2026',
          content: (
            <div className="space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              <p>
                हम 100% सटीकता के लिए प्रतिबद्ध हैं। यदि आपको हमारे किसी भी लेख, आंकड़े, या कैलकुलेटर में कोई तथ्यात्मक त्रुटि दिखाई देती है, तो हम उसका त्वरित सुधार करते हैं।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">त्रुटि की रिपोर्ट कैसे करें</h3>
              <p>
                आप हमें <strong>corrections@financegyanindia.com</strong> पर लेख के लिंक और सही संदर्भ के साथ ईमेल कर सकते हैं। हमारी टीम 24 घंटों के भीतर समीक्षा कर आवश्यक संशोधन करेगी और लेख पर अपडेट की तारीख अंकित करेगी।
              </p>
            </div>
          )
        };

      case 'cookie-policy':
      default:
        return {
          title: lang === 'hi' ? 'कुकी नीति (Cookie Policy)' : 'Cookie Policy',
          updated: '1 अप्रैल 2026',
          content: (
            <div className="space-y-6 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
              <p>
                यह नीति बताती है कि Finance Gyan India आपकी ब्राउज़िंग प्राथमिकताएं याद रखने और विश्लेषिकी हेतु कुकीज़ का उपयोग कैसे करता है।
              </p>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">कुकीज़ का प्रबंधन</h3>
              <p>
                आप अपने वेब ब्राउज़र की सेटिंग्स में जाकर कुकीज़ को ब्लॉक या डिलीट कर सकते हैं। हालांकि कुछ कुकीज़ को बंद करने से कैलकुलेटर की सहेजी गई प्राथमिकताएं रीसेट हो सकती हैं।
              </p>
            </div>
          )
        };
    }
  };

  const doc = getDocDetails();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Breadcrumbs items={[{ label: doc.title }]} navigate={navigate} />

      <div className="mt-4 mb-8 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 text-xs font-semibold text-teal-700 dark:text-teal-400 uppercase tracking-wider">
          <ShieldCheck className="w-4 h-4" />
          <span>{lang === 'hi' ? 'पारदर्शिता एवं कानूनी नीतियां' : 'Legal & Trust'}</span>
        </div>
        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mt-1">
          {doc.title}
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          {lang === 'hi' ? `अंतिम नवीनीकरण: ${doc.updated}` : `Last Updated: ${doc.updated}`}
        </p>
      </div>

      <div className="bg-white dark:bg-slate-800/90 rounded-2xl p-6 sm:p-10 border border-slate-200 dark:border-slate-800 shadow-sm">
        {doc.content}
      </div>
    </div>
  );
};
