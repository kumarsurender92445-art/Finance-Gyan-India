export type Language = 'hi' | 'en';

export interface Author {
  id: string;
  name: string;
  nameHi: string;
  role: string;
  roleHi: string;
  bio: string;
  bioHi: string;
  avatar: string;
  credentials: string[];
  articleCount: number;
  twitter?: string;
  linkedin?: string;
  email?: string;
}

export interface Category {
  id: string;
  slug: string;
  name: string;
  nameHi: string;
  description: string;
  descriptionHi: string;
  iconName: string;
  color: string;
  articleCount: number;
}

export interface ArticleFAQ {
  question: string;
  answer: string;
}

export interface OfficialSource {
  title: string;
  url: string;
  authority: string; // e.g. "RBI", "SEBI", "Income Tax Dept", "AMFI"
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  titleHi: string;
  excerpt: string;
  excerptHi: string;
  categorySlug: string;
  authorId: string;
  publishedDate: string;
  updatedDate: string;
  readTimeMinutes: number;
  featuredImage: string;
  featuredImageAlt: string;
  isFeatured?: boolean;
  isTrending?: boolean;
  tags: string[];
  content: {
    introduction: string;
    sections: {
      id: string;
      title: string;
      content: string;
      callout?: {
        type: 'info' | 'warning' | 'tip';
        title: string;
        text: string;
      };
      table?: {
        headers: string[];
        rows: string[][];
      };
      prosAndCons?: {
        pros: string[];
        cons: string[];
      };
    }[];
    faqs: ArticleFAQ[];
    officialSources: OfficialSource[];
    disclaimer: string;
  };
}

export interface CalculatorField {
  id: string;
  label: string;
  labelHi: string;
  defaultValue: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  tooltip?: string;
}

export interface CalculatorConfig {
  id: string;
  slug: string;
  name: string;
  nameHi: string;
  description: string;
  descriptionHi: string;
  category: 'investment' | 'loans' | 'banking' | 'planning' | 'tax';
  iconName: string;
  fields: CalculatorField[];
  formulaExplanation: {
    formula: string;
    explanationHi: string;
    variables: { symbol: string; nameHi: string; desc: string }[];
  };
  assumptions: string[];
}
